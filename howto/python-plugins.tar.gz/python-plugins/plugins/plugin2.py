from plugins.interface import PluginInterface

class plugin2cl(PluginInterface):
    def func1(self):
        print "method1 of plugin 2"
        
    def func2(self):
        print "method2 of plugin 2"
        
def func1():
    print "func1 of plugin 2"