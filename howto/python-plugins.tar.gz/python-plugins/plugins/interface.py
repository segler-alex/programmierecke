class PluginInterface(object):
    def func1(self):
        raise NotImplementedError
    
    def func2(self):
        raise NotImplementedError