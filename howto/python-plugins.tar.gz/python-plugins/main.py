import imp
import pkgutil
import os
import sys

from plugins.interface import PluginInterface
plugin_path = "plugins/"

#for loader,name,ispkg in pkgutil.iter_modules(plugin_path):
for name in ["plugin1","plugin2"]:
    print name
    file, pathname, desc = imp.find_module(name, [plugin_path,])
    module = imp.load_module(name, file, pathname, desc)
    
    module.func1()

for i in  PluginInterface.__subclasses__():
    c = i()
    c.func2()