// Kartei1.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Testkartei.h"
#include "Kartei1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Kartei1 


Kartei1::Kartei1(Personset *personi,CWnd* pParent /*=NULL*/)
	: CDialog(Kartei1::IDD, pParent)
{
	m_person=personi;
	//{{AFX_DATA_INIT(Kartei1)
	m_name = _T("");
	m_ort = _T("");
	m_beruf = _T("");
	m_id = 0;
	//}}AFX_DATA_INIT
}


void Kartei1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Kartei1)
	DDX_Control(pDX, IDC_ZURUECK, m_zurueck);
	DDX_Control(pDX, IDC_WEITER, m_weiter);
	DDX_Text(pDX, IDC_EDIT1, m_name);
	DDX_Text(pDX, IDC_EDIT2, m_ort);
	DDX_Text(pDX, IDC_EDIT3, m_beruf);
	DDX_Text(pDX, IDC_EDIT5, m_id);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Kartei1, CDialog)
	//{{AFX_MSG_MAP(Kartei1)
	ON_BN_CLICKED(IDC_ZURUECK, OnZurueck)
	ON_BN_CLICKED(IDC_WEITER, OnWeiter)
	ON_BN_CLICKED(IDC_NEU, OnNeu)
	ON_BN_CLICKED(IDC_DEL, OnDel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Kartei1 

void Kartei1::OnZurueck() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_person->MovePrev();
	checkbuttons();	
}

void Kartei1::OnWeiter() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_person->MoveNext();
	checkbuttons();
}

void Kartei1::OnNeu() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	this->UpdateData(true);
	m_person->AddNew();
	m_person->m_id=m_id;
	m_person->m_beruf=m_beruf;
	m_person->m_name=m_name;
	m_person->m_ort=m_ort;
	m_person->Update();
	m_person->Requery();
	checkbuttons();
}

BOOL Kartei1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen
	if (!m_person->IsBOF()){
		checkbuttons();
	}
	else{
		m_weiter.EnableWindow(false);
		m_zurueck.EnableWindow(false);
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void Kartei1::checkbuttons()
{
	if (!m_person->IsBOF()||!m_person->IsEOF()){
		m_person->MoveNext();
		if (m_person->IsEOF())
			m_weiter.EnableWindow(false);
		else m_weiter.EnableWindow(true);
		m_person->MovePrev();
		m_person->MovePrev();
		if (m_person->IsBOF())
			m_zurueck.EnableWindow(false);
		else m_zurueck.EnableWindow(true);
		m_person->MoveNext();
		m_beruf=m_person->m_beruf;
		m_ort=m_person->m_ort;
		m_name=m_person->m_name;
		m_id=m_person->m_id;
		this->UpdateData(false);
	}
	else{
		m_zurueck.EnableWindow(false);
		m_weiter.EnableWindow(false);
		m_beruf="";
		m_ort="";
		m_name="";
		m_id=0;
		this->UpdateData(false);
	}

}

void Kartei1::OnDel() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_person->Delete();
	m_person->Requery();
	checkbuttons();
}
