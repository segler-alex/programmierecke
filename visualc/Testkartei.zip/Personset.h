#if !defined(AFX_PERSONSET_H__2547582D_FC15_4F1A_9B17_7F7A818B95C2__INCLUDED_)
#define AFX_PERSONSET_H__2547582D_FC15_4F1A_9B17_7F7A818B95C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Personset.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe Personset 

class Personset : public CRecordset
{
public:
	Personset(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(Personset)

// Feld-/Parameterdaten
	//{{AFX_FIELD(Personset, CRecordset)
	long	m_id;
	CString	m_name;
	CString	m_ort;
	CString	m_beruf;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Personset)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_PERSONSET_H__2547582D_FC15_4F1A_9B17_7F7A818B95C2__INCLUDED_
