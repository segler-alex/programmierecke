#if !defined(AFX_KARTEI1_H__A2CF30FC_0D4C_4BB7_A630_D47FB9E3F2C9__INCLUDED_)
#define AFX_KARTEI1_H__A2CF30FC_0D4C_4BB7_A630_D47FB9E3F2C9__INCLUDED_

#include "Personset.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Kartei1.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Kartei1 

class Kartei1 : public CDialog
{
// Konstruktion
public:
	void checkbuttons();
	Personset *m_person;
	Kartei1(Personset *personi,CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(Kartei1)
	enum { IDD = IDD_KARTEI1 };
	CButton	m_zurueck;
	CButton	m_weiter;
	CString	m_name;
	CString	m_ort;
	CString	m_beruf;
	int		m_id;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Kartei1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Kartei1)
	afx_msg void OnZurueck();
	afx_msg void OnWeiter();
	afx_msg void OnNeu();
	virtual BOOL OnInitDialog();
	afx_msg void OnDel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_KARTEI1_H__A2CF30FC_0D4C_4BB7_A630_D47FB9E3F2C9__INCLUDED_
