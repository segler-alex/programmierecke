// TestkarteiView.h : Schnittstelle der Klasse CTestkarteiView
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTKARTEIVIEW_H__CB578F97_5F98_43C7_9144_7DF6F2135847__INCLUDED_)
#define AFX_TESTKARTEIVIEW_H__CB578F97_5F98_43C7_9144_7DF6F2135847__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "Kartei1.h"
#include "GKartei.h"
#include "Personset.h"

class CTestkarteiView : public CFormView
{
protected: // Nur aus Serialisierung erzeugen
	CTestkarteiView();
	DECLARE_DYNCREATE(CTestkarteiView)

public:
	//{{AFX_DATA(CTestkarteiView)
	enum { IDD = IDD_TESTKARTEI_FORM };
	CTabCtrl	m_ctab;
	//}}AFX_DATA

// Attribute
public:
	CTestkarteiDoc* GetDocument();

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CTestkarteiView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	virtual void OnInitialUpdate(); // das erste mal nach der Konstruktion aufgerufen
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementierung
public:
	Personset * person;
	Kartei1 * dlg1;
	GKartei * dlg2;
	virtual ~CTestkarteiView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CTestkarteiView)
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // Testversion in TestkarteiView.cpp
inline CTestkarteiDoc* CTestkarteiView::GetDocument()
   { return (CTestkarteiDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_TESTKARTEIVIEW_H__CB578F97_5F98_43C7_9144_7DF6F2135847__INCLUDED_)
