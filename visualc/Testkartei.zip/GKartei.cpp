// GKartei.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Testkartei.h"
#include "GKartei.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld GKartei 


GKartei::GKartei(Personset *personi,CWnd* pParent /*=NULL*/)
	: CDialog(GKartei::IDD, pParent)
{
	m_person=personi;
	//{{AFX_DATA_INIT(GKartei)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT
}


void GKartei::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GKartei)
	DDX_Control(pDX, IDC_TREE1, m_ctree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GKartei, CDialog)
	//{{AFX_MSG_MAP(GKartei)
	ON_BN_CLICKED(IDC_UPDATE, OnUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten GKartei 

BOOL GKartei::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen
	OnUpdate();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void GKartei::OnUpdate() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_ctree.DeleteAllItems();
	HTREEITEM h;
	if (m_person->GetRecordCount()!=0){
		m_person->MoveFirst();
		while (!m_person->IsEOF()){
			h=m_ctree.InsertItem(m_person->m_name);
			h=m_ctree.InsertItem(m_person->m_ort,h);
			m_ctree.InsertItem(m_person->m_beruf,h);
			m_person->MoveNext();
		}
		m_person->MoveFirst();
	}
}
