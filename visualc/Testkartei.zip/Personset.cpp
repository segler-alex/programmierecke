// Personset.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Testkartei.h"
#include "Personset.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Personset

IMPLEMENT_DYNAMIC(Personset, CRecordset)

Personset::Personset(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(Personset)
	m_id = 0;
	m_name = _T("");
	m_ort = _T("");
	m_beruf = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString Personset::GetDefaultConnect()
{
	return _T("ODBC;DSN=Microsoft Access-Datenbank");
}

CString Personset::GetDefaultSQL()
{
	return _T("[Person]");
}

void Personset::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(Personset)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Text(pFX, _T("[name]"), m_name);
	RFX_Text(pFX, _T("[ort]"), m_ort);
	RFX_Text(pFX, _T("[beruf]"), m_beruf);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose Personset

#ifdef _DEBUG
void Personset::AssertValid() const
{
	CRecordset::AssertValid();
}

void Personset::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
