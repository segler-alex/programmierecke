// TestkarteiView.cpp : Implementierung der Klasse CTestkarteiView
//

#include "stdafx.h"
#include "Testkartei.h"

#include "TestkarteiDoc.h"
#include "TestkarteiView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiView

IMPLEMENT_DYNCREATE(CTestkarteiView, CFormView)

BEGIN_MESSAGE_MAP(CTestkarteiView, CFormView)
	//{{AFX_MSG_MAP(CTestkarteiView)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab1)
	//}}AFX_MSG_MAP
	// Standard-Druckbefehle
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiView Konstruktion/Destruktion

CTestkarteiView::CTestkarteiView()
	: CFormView(CTestkarteiView::IDD)
{
	//{{AFX_DATA_INIT(CTestkarteiView)
		// HINWEIS: Der Klassenassistent f�gt hier Member-Initialisierung ein
	//}}AFX_DATA_INIT
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen,

}

CTestkarteiView::~CTestkarteiView()
{
}

void CTestkarteiView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestkarteiView)
	DDX_Control(pDX, IDC_TAB1, m_ctab);
	//}}AFX_DATA_MAP
}

BOOL CTestkarteiView::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return CFormView::PreCreateWindow(cs);
}

void CTestkarteiView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	person=new Personset();
	person->Open();
	m_ctab.InsertItem(0,"Person");
	m_ctab.InsertItem(1,"Personbaum");
	dlg1=new Kartei1(person);
	dlg2=new GKartei(person);
	dlg1->Create(IDD_KARTEI1,&m_ctab);
	dlg2->Create(IDD_KARTEI2,&m_ctab);
	RECT r;
	m_ctab.GetClientRect(&r);
	dlg1->SetWindowPos(NULL,r.left+5,r.top+25,0,0,SWP_NOSIZE||SWP_NOZORDER);
	dlg1->ShowWindow(SW_SHOW);
	dlg1->SetFocus();
}

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiView Drucken

BOOL CTestkarteiView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Standardvorbereitung
	return DoPreparePrinting(pInfo);
}

void CTestkarteiView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Zus�tzliche Initialisierung vor dem Drucken hier einf�gen
}

void CTestkarteiView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Hier Bereinigungsarbeiten nach dem Drucken einf�gen
}

void CTestkarteiView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Benutzerdefinierten Code zum Ausdrucken hier einf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiView Diagnose

#ifdef _DEBUG
void CTestkarteiView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTestkarteiView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CTestkarteiDoc* CTestkarteiView::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestkarteiDoc)));
	return (CTestkarteiDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiView Nachrichten-Handler

void CTestkarteiView::OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	RECT r;
	m_ctab.GetClientRect(&r);
	if (m_ctab.GetCurSel()==0){
		dlg1->SetWindowPos(NULL,r.left+5,r.top+25,0,0,SWP_NOSIZE||SWP_NOZORDER);
		dlg1->ShowWindow(SW_SHOW);
		dlg1->SetFocus();
	}
	else dlg1->ShowWindow(SW_HIDE);
	if (m_ctab.GetCurSel()==1){
		dlg2->SetWindowPos(NULL,r.left+5,r.top+25,0,0,SWP_NOSIZE||SWP_NOZORDER);
		dlg2->ShowWindow(SW_SHOW);
		dlg2->SetFocus();
	}
	else dlg2->ShowWindow(SW_HIDE);


	*pResult = 0;
}
