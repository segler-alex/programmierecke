// Kartei2.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Testkartei.h"
#include "Kartei2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Kartei2 


Kartei2::Kartei2(CWnd* pParent /*=NULL*/)
	: CDialog(Kartei2::IDD, pParent)
{
	//{{AFX_DATA_INIT(Kartei2)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT
}


void Kartei2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Kartei2)
		// HINWEIS: Der Klassen-Assistent f�gt hier DDX- und DDV-Aufrufe ein
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Kartei2, CDialog)
	//{{AFX_MSG_MAP(Kartei2)
		// HINWEIS: Der Klassen-Assistent f�gt hier Zuordnungsmakros f�r Nachrichten ein
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Kartei2 
