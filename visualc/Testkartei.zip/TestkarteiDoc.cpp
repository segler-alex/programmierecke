// TestkarteiDoc.cpp : Implementierung der Klasse CTestkarteiDoc
//

#include "stdafx.h"
#include "Testkartei.h"

#include "TestkarteiDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiDoc

IMPLEMENT_DYNCREATE(CTestkarteiDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestkarteiDoc, CDocument)
	//{{AFX_MSG_MAP(CTestkarteiDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiDoc Konstruktion/Destruktion

CTestkarteiDoc::CTestkarteiDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CTestkarteiDoc::~CTestkarteiDoc()
{
}

BOOL CTestkarteiDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTestkarteiDoc Serialisierung

void CTestkarteiDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// ZU ERLEDIGEN: Hier Code zum Speichern einf�gen
	}
	else
	{
		// ZU ERLEDIGEN: Hier Code zum Laden einf�gen
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiDoc Diagnose

#ifdef _DEBUG
void CTestkarteiDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestkarteiDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestkarteiDoc Befehle
