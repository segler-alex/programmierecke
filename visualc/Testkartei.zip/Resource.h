//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Testkartei.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_TESTKARTEI_FORM             101
#define IDR_MAINFRAME                   128
#define IDR_TESTKATYPE                  129
#define IDD_KARTEI1                     130
#define IDD_KARTEI2                     131
#define IDC_TAB1                        1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_ZURUECK                     1004
#define IDC_NEU                         1005
#define IDC_WEITER                      1007
#define IDC_TREE1                       1008
#define IDC_EDIT5                       1009
#define IDC_UPDATE                      1010
#define IDC_DEL                         1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
