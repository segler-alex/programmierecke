#if !defined(AFX_KARTEI2_H__0DB4F28B_0444_4AC0_B9E6_BE598096E65A__INCLUDED_)
#define AFX_KARTEI2_H__0DB4F28B_0444_4AC0_B9E6_BE598096E65A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Kartei2.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Kartei2 

class Kartei2 : public CDialog
{
// Konstruktion
public:
	Kartei2(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(Kartei2)
	enum { IDD = IDD_KARTEI2 };
		// HINWEIS: Der Klassen-Assistent f�gt hier Datenelemente ein
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Kartei2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Kartei2)
		// HINWEIS: Der Klassen-Assistent f�gt hier Member-Funktionen ein
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_KARTEI2_H__0DB4F28B_0444_4AC0_B9E6_BE598096E65A__INCLUDED_
