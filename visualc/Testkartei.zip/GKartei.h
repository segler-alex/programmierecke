#if !defined(AFX_GKARTEI_H__952F5B66_4D42_434C_B73C_7B1B69A2E0C7__INCLUDED_)
#define AFX_GKARTEI_H__952F5B66_4D42_434C_B73C_7B1B69A2E0C7__INCLUDED_

#include "Personset.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GKartei.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld GKartei 

class GKartei : public CDialog
{
// Konstruktion
public:
	Personset *m_person;
	GKartei(Personset *personi,CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(GKartei)
	enum { IDD = IDD_KARTEI2 };
	CTreeCtrl	m_ctree;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(GKartei)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(GKartei)
	virtual BOOL OnInitDialog();
	afx_msg void OnUpdate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_GKARTEI_H__952F5B66_4D42_434C_B73C_7B1B69A2E0C7__INCLUDED_
