// Schuelerinfo.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "Schuelerinfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Schuelerinfo 


Schuelerinfo::Schuelerinfo(CWnd* pParent /*=NULL*/)
	: CDialog(Schuelerinfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(Schuelerinfo)
	m_ID = 0;
	m_land = _T("");
	m_nname = _T("");
	m_raum = _T("");
	m_vname = _T("");
	//}}AFX_DATA_INIT
}


void Schuelerinfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Schuelerinfo)
	DDX_Text(pDX, IDC_ID, m_ID);
	DDX_Text(pDX, IDC_LAND, m_land);
	DDX_Text(pDX, IDC_NACHNAME, m_nname);
	DDX_Text(pDX, IDC_RAUM, m_raum);
	DDX_Text(pDX, IDC_VORNAME, m_vname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Schuelerinfo, CDialog)
	//{{AFX_MSG_MAP(Schuelerinfo)
		// HINWEIS: Der Klassen-Assistent f�gt hier Zuordnungsmakros f�r Nachrichten ein
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Schuelerinfo 
