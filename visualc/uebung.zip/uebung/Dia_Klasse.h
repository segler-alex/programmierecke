#if !defined(AFX_DIA_KLASSE_H__F4B1F718_5085_47EA_92C7_835158D8EA6E__INCLUDED_)
#define AFX_DIA_KLASSE_H__F4B1F718_5085_47EA_92C7_835158D8EA6E__INCLUDED_

#include "KlasseRec.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dia_Klasse.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Dia_Klasse 

class Dia_Klasse : public CPropertyPage
{
	DECLARE_DYNCREATE(Dia_Klasse)

// Konstruktion
public:
	KlasseRec klasse;
	void DBUpdate(bool toDB);
	Dia_Klasse();
	~Dia_Klasse();

// Dialogfelddaten
	//{{AFX_DATA(Dia_Klasse)
	enum { IDD = IDD_KLASSE };
	CString	m_raum;
	int		m_klasseid;
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Dia_Klasse)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Dia_Klasse)
	afx_msg void OnUpdate();
	afx_msg void OnAdd();
	virtual BOOL OnInitDialog();
	afx_msg void OnDelete();
	afx_msg void OnLeft();
	afx_msg void OnRight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIA_KLASSE_H__F4B1F718_5085_47EA_92C7_835158D8EA6E__INCLUDED_
