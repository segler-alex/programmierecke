// SchuelerRec.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "SchuelerRec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SchuelerRec

IMPLEMENT_DYNAMIC(SchuelerRec, CRecordset)

SchuelerRec::SchuelerRec(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(SchuelerRec)
	m_SchuelerID = 0;
	m_Vorname = _T("");
	m_Nachname = _T("");
	m_Adresse = _T("");
	m_PLZ = _T("");
	m_LandID = 0;
	m_KlasseID = 0;
	m_nFields = 10;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString SchuelerRec::GetDefaultConnect()
{
	return _T("ODBC;DSN=uebung");
}

CString SchuelerRec::GetDefaultSQL()
{
	return _T("[Schueler]");
}

void SchuelerRec::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(SchuelerRec)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[SchuelerID]"), m_SchuelerID);
	RFX_Text(pFX, _T("[Vorname]"), m_Vorname);
	RFX_Text(pFX, _T("[Nachname]"), m_Nachname);
	RFX_Date(pFX, _T("[GeborenAm]"), m_GeborenAm);
	RFX_Date(pFX, _T("[EingetretenAm]"), m_EingetretenAm);
	RFX_Date(pFX, _T("[AusgetretenAm]"), m_AusgetretenAm);
	RFX_Text(pFX, _T("[Adresse]"), m_Adresse);
	RFX_Text(pFX, _T("[PLZ]"), m_PLZ);
	RFX_Long(pFX, _T("[LandID]"), m_LandID);
	RFX_Long(pFX, _T("[KlasseID]"), m_KlasseID);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose SchuelerRec

#ifdef _DEBUG
void SchuelerRec::AssertValid() const
{
	CRecordset::AssertValid();
}

void SchuelerRec::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
