// Dia_Tree.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "Dia_Tree.h"
#include "SchuelerInfo.h"

#include "SchuelerRec.h"
#include "KlasseRec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite Dia_Tree 

IMPLEMENT_DYNCREATE(Dia_Tree, CPropertyPage)

Dia_Tree::Dia_Tree() : CPropertyPage(Dia_Tree::IDD)
{
	//{{AFX_DATA_INIT(Dia_Tree)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT
}

Dia_Tree::~Dia_Tree()
{
}

void Dia_Tree::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Dia_Tree)
	DDX_Control(pDX, IDC_TREE, m_tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Dia_Tree, CPropertyPage)
	//{{AFX_MSG_MAP(Dia_Tree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE, OnSelchangedTree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Dia_Tree 

BOOL Dia_Tree::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	KlasseRec klasserec;
	SchuelerRec schuelerrec;

	klasserec.Open();
	schuelerrec.Open();

	while (!klasserec.IsEOF())
	{
		HTREEITEM h = m_tree.InsertItem(klasserec.m_Raum,-1,-1);
		klasserec.MoveNext();
		
		while (!schuelerrec.IsEOF())
		{
			if (schuelerrec.m_KlasseID == klasserec.m_KlasseID)
			{
				HTREEITEM s = m_tree.InsertItem(schuelerrec.m_Nachname, -1,-1,h);
				m_tree.SetItemData(s,schuelerrec.m_SchuelerID);
			}
		schuelerrec.MoveNext();
		}

	}
	klasserec.Close();
	schuelerrec.Close();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void Dia_Tree::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// Angeklicktes Item
	NM_TREEVIEW* item = (NM_TREEVIEW*) pNMHDR;

	// Existiert Item..
	if (item->itemNew.hItem != NULL)
	{
		if (item->itemNew.lParam != NULL)
		{
			Schuelerinfo info;
			SchuelerRec schueler;
			schueler.Open();
			schueler.m_strFilter.Format("SchuelerID=%ld",item->itemNew.lParam);
			schueler.Requery();

			LandRec land;
			land.Open();
			land.m_strFilter.Format("LandID=%ld",schueler.m_LandID);
			land.Requery();
			land.Close();
			info.m_nname = schueler.m_Nachname;
			info.m_land = land.m_Bezeichnung;
			info.DoModal();
			schueler.Close();
		}
	}
	*pResult = 0;
}
