#if !defined(AFX_DIA_TREE_H__F5CD6D6A_D48B_456D_90E7_EBE794BD21C5__INCLUDED_)
#define AFX_DIA_TREE_H__F5CD6D6A_D48B_456D_90E7_EBE794BD21C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dia_Tree.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Dia_Tree 

class Dia_Tree : public CPropertyPage
{
	DECLARE_DYNCREATE(Dia_Tree)

// Konstruktion
public:
	Dia_Tree();
	~Dia_Tree();

// Dialogfelddaten
	//{{AFX_DATA(Dia_Tree)
	enum { IDD = IDD_TREE };
	CTreeCtrl	m_tree;
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Dia_Tree)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Dia_Tree)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIA_TREE_H__F5CD6D6A_D48B_456D_90E7_EBE794BD21C5__INCLUDED_
