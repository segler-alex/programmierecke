#if !defined(AFX_LANDREC_H__1EF8C0A2_65DC_452A_A249_175829AB6FAD__INCLUDED_)
#define AFX_LANDREC_H__1EF8C0A2_65DC_452A_A249_175829AB6FAD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LandRec.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe LandRec 

class LandRec : public CRecordset
{
public:
	LandRec(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(LandRec)

// Feld-/Parameterdaten
	//{{AFX_FIELD(LandRec, CRecordset)
	long	m_LandID;
	CString	m_ISO;
	CString	m_Bezeichnung;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(LandRec)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_LANDREC_H__1EF8C0A2_65DC_452A_A249_175829AB6FAD__INCLUDED_
