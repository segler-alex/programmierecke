#if !defined(AFX_SCHUELERINFO_H__590D78D2_F00B_4645_A457_9EFA492ABB0C__INCLUDED_)
#define AFX_SCHUELERINFO_H__590D78D2_F00B_4645_A457_9EFA492ABB0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Schuelerinfo.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Schuelerinfo 

class Schuelerinfo : public CDialog
{
// Konstruktion
public:
	Schuelerinfo(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(Schuelerinfo)
	enum { IDD = IDD_SCHUELERINFO };
	int		m_ID;
	CString	m_land;
	CString	m_nname;
	CString	m_raum;
	CString	m_vname;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Schuelerinfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Schuelerinfo)
		// HINWEIS: Der Klassen-Assistent f�gt hier Member-Funktionen ein
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_SCHUELERINFO_H__590D78D2_F00B_4645_A457_9EFA492ABB0C__INCLUDED_
