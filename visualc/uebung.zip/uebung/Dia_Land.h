#if !defined(AFX_DIA_LAND_H__6FDA56A9_C3CB_4DEC_8A53_134650DCCF99__INCLUDED_)
#define AFX_DIA_LAND_H__6FDA56A9_C3CB_4DEC_8A53_134650DCCF99__INCLUDED_

#include "LandRec.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dia_Land.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Dia_Land 

class Dia_Land : public CPropertyPage
{
	DECLARE_DYNCREATE(Dia_Land)

// Konstruktion
public:
	LandRec land;
	void DBUpdate(bool toDB);
	Dia_Land();
	~Dia_Land();

// Dialogfelddaten
	//{{AFX_DATA(Dia_Land)
	enum { IDD = IDD_LAND };
	CString	m_bez;
	CString	m_iso;
	CString	m_landid;
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Dia_Land)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Dia_Land)
	afx_msg void OnAdd();
	afx_msg void OnUpdate();
	afx_msg void OnDelete();
	virtual BOOL OnInitDialog();
	afx_msg void OnLeft();
	afx_msg void OnRight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIA_LAND_H__6FDA56A9_C3CB_4DEC_8A53_134650DCCF99__INCLUDED_
