#if !defined(AFX_DIA_SCHUELER_H__0B6709FB_15E8_4F50_A83A_51564AC1F210__INCLUDED_)
#define AFX_DIA_SCHUELER_H__0B6709FB_15E8_4F50_A83A_51564AC1F210__INCLUDED_

#include "SchuelerRec.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dia_Schueler.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Dia_Schueler 

class Dia_Schueler : public CPropertyPage
{
	DECLARE_DYNCREATE(Dia_Schueler)

// Konstruktion
public:
	void refillcombo();
	void DBUpdate (bool toDB);
	SchuelerRec schueler;
	Dia_Schueler();
	~Dia_Schueler();

// Dialogfelddaten
	//{{AFX_DATA(Dia_Schueler)
	enum { IDD = IDD_SCHUELER };
	CComboBox	m_klasse;
	CComboBox	m_land;
	CString	m_nname;
	int		m_schuelerid;
	CString	m_vname;
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Dia_Schueler)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Dia_Schueler)
	afx_msg void OnAdd();
	virtual BOOL OnInitDialog();
	afx_msg void OnUpdate();
	afx_msg void OnDelete();
	afx_msg void OnLeft();
	afx_msg void OnRight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIA_SCHUELER_H__0B6709FB_15E8_4F50_A83A_51564AC1F210__INCLUDED_
