#if !defined(AFX_KLASSEREC_H__031BF723_A757_4154_B1AA_6C3FA049337D__INCLUDED_)
#define AFX_KLASSEREC_H__031BF723_A757_4154_B1AA_6C3FA049337D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KlasseRec.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe KlasseRec 

class KlasseRec : public CRecordset
{
public:
	KlasseRec(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(KlasseRec)

// Feld-/Parameterdaten
	//{{AFX_FIELD(KlasseRec, CRecordset)
	long	m_KlasseID;
	CString	m_Raum;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(KlasseRec)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_KLASSEREC_H__031BF723_A757_4154_B1AA_6C3FA049337D__INCLUDED_
