#if !defined(AFX_SCHUELERREC_H__DE43B65F_8BEE_4B10_8CA3_AA20A9A550B1__INCLUDED_)
#define AFX_SCHUELERREC_H__DE43B65F_8BEE_4B10_8CA3_AA20A9A550B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SchuelerRec.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe SchuelerRec 

class SchuelerRec : public CRecordset
{
public:
	SchuelerRec(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(SchuelerRec)

// Feld-/Parameterdaten
	//{{AFX_FIELD(SchuelerRec, CRecordset)
	long	m_SchuelerID;
	CString	m_Vorname;
	CString	m_Nachname;
	CTime	m_GeborenAm;
	CTime	m_EingetretenAm;
	CTime	m_AusgetretenAm;
	CString	m_Adresse;
	CString	m_PLZ;
	long	m_LandID;
	long	m_KlasseID;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(SchuelerRec)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_SCHUELERREC_H__DE43B65F_8BEE_4B10_8CA3_AA20A9A550B1__INCLUDED_
