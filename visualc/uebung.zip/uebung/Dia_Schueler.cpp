// Dia_Schueler.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "Dia_Schueler.h"
#include "KlasseRec.h"
#include "LandRec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite Dia_Schueler 

IMPLEMENT_DYNCREATE(Dia_Schueler, CPropertyPage)

Dia_Schueler::Dia_Schueler() : CPropertyPage(Dia_Schueler::IDD)
{
	//{{AFX_DATA_INIT(Dia_Schueler)
	m_nname = _T("");
	m_schuelerid = 0;
	m_vname = _T("");
	//}}AFX_DATA_INIT
}

Dia_Schueler::~Dia_Schueler()
{
}

void Dia_Schueler::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Dia_Schueler)
	DDX_Control(pDX, IDC_KLASSE, m_klasse);
	DDX_Control(pDX, IDC_LAND, m_land);
	DDX_Text(pDX, IDC_NNAME, m_nname);
	DDX_Text(pDX, IDC_SCHUELER, m_schuelerid);
	DDX_Text(pDX, IDC_VNAME, m_vname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Dia_Schueler, CPropertyPage)
	//{{AFX_MSG_MAP(Dia_Schueler)
	ON_BN_CLICKED(IDC_BUTTON1, OnAdd)
	ON_BN_CLICKED(IDC_BUTTON2, OnUpdate)
	ON_BN_CLICKED(IDC_BUTTON3, OnDelete)
	ON_BN_CLICKED(IDC_BUTTON4, OnLeft)
	ON_BN_CLICKED(IDC_BUTTON5, OnRight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Dia_Schueler 

void Dia_Schueler::OnAdd() 
{
	schueler.AddNew();
	UpdateData(TRUE);
	DBUpdate(true);
	schueler.Update();
	schueler.Requery();
	DBUpdate(false);
	UpdateData(FALSE);
}

BOOL Dia_Schueler::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	schueler.Open();
	refillcombo();
	DBUpdate(false);
	UpdateData(FALSE);
	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void Dia_Schueler::OnUpdate() 
{
	schueler.Edit();
	UpdateData(TRUE);
	DBUpdate(true);
	schueler.Update();
}

void Dia_Schueler::OnDelete() 
{
	schueler.Delete();
	schueler.Requery();
	DBUpdate(false);
	UpdateData(FALSE);
}

void Dia_Schueler::DBUpdate(bool toDB)
{
	if (toDB)
	{
		schueler.m_Vorname = this->m_vname;
		schueler.m_Nachname = this->m_nname;
		if (m_land.GetCurSel() != -1)
		{
			schueler.m_LandID = this->m_land.GetItemData(m_land.GetCurSel());
		}
		if (m_klasse.GetCurSel() != -1)
		{
			schueler.m_KlasseID = this->m_klasse.GetItemData(m_klasse.GetCurSel());
		}
	}else
	{
		this->m_vname = schueler.m_Vorname;
		this->m_nname = schueler.m_Nachname;
		
		for (int i =0;i<this->m_land.GetCount();i++)
		{
			if (m_land.GetItemData(i) == schueler.m_LandID)
			{
				m_land.SetCurSel(i);
				break;
			}
		}
	
		for (i=0;i<this->m_klasse.GetCount();i++)
		{
			if (m_klasse.GetItemData(i) == schueler.m_KlasseID)
			{
				m_klasse.SetCurSel(i);
				break;
			}
		}
	}

}

void Dia_Schueler::refillcombo()
{
	KlasseRec klasserec;
	LandRec landrec;
	klasserec.Open();
	landrec.Open();
		
	while (!klasserec.IsEOF())
	{
		int item = m_klasse.AddString(klasserec.m_Raum);
		m_klasse.SetItemData(item,klasserec.m_KlasseID);
		klasserec.MoveNext();
	}
	klasserec.Close();

	while (!landrec.IsEOF())
	{
		int item = m_land.AddString(landrec.m_Bezeichnung);
		m_land.SetItemData(item,landrec.m_LandID);
		landrec.MoveNext();
	}
	landrec.Close();
}

void Dia_Schueler::OnLeft() 
{
	schueler.MovePrev();
	DBUpdate(false);
	UpdateData(FALSE);
}

void Dia_Schueler::OnRight() 
{
	schueler.MoveNext();
	DBUpdate(false);
	UpdateData(FALSE);
}
