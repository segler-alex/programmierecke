// Dia_Klasse.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "Dia_Klasse.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite Dia_Klasse 

IMPLEMENT_DYNCREATE(Dia_Klasse, CPropertyPage)

Dia_Klasse::Dia_Klasse() : CPropertyPage(Dia_Klasse::IDD)
{
	//{{AFX_DATA_INIT(Dia_Klasse)
	m_raum = _T("");
	m_klasseid = 0;
	//}}AFX_DATA_INIT
}

Dia_Klasse::~Dia_Klasse()
{
}

void Dia_Klasse::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Dia_Klasse)
	DDX_Text(pDX, IDC_RAUM, m_raum);
	DDX_Text(pDX, IDC_KLASSEID, m_klasseid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Dia_Klasse, CPropertyPage)
	//{{AFX_MSG_MAP(Dia_Klasse)
	ON_BN_CLICKED(IDC_BUTTON2, OnUpdate)
	ON_BN_CLICKED(IDC_BUTTON1, OnAdd)
	ON_BN_CLICKED(IDC_BUTTON3, OnDelete)
	ON_BN_CLICKED(IDC_BUTTON4, OnLeft)
	ON_BN_CLICKED(IDC_BUTTON5, OnRight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Dia_Klasse 

void Dia_Klasse::DBUpdate(bool toDB)
{
	if (toDB)
	{
		klasse.m_Raum = this->m_raum;
	}else
	{
		this->m_raum = klasse.m_Raum;
		this->m_klasseid = klasse.m_KlasseID;
	}
}

void Dia_Klasse::OnUpdate() 
{
	klasse.Edit();
	UpdateData(TRUE);
	DBUpdate(true);
	klasse.Update();
}

void Dia_Klasse::OnAdd() 
{
	klasse.AddNew();
	UpdateData(TRUE);
	DBUpdate(true);
	klasse.Update();
	klasse.Requery();
	DBUpdate(false);
	UpdateData(FALSE);
}

BOOL Dia_Klasse::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	klasse.Open();
	DBUpdate(false);
	UpdateData(FALSE);

	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void Dia_Klasse::OnDelete() 
{
	klasse.Delete();
	klasse.Requery();
	DBUpdate(false);
	UpdateData(FALSE);
}

void Dia_Klasse::OnLeft() 
{
	klasse.MovePrev();
	DBUpdate(false);		
	UpdateData(FALSE);
}

void Dia_Klasse::OnRight() 
{
	klasse.MoveNext();
	DBUpdate(false);
	UpdateData(FALSE);
}
