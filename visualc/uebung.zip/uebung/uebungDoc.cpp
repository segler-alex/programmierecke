// uebungDoc.cpp : Implementierung der Klasse CUebungDoc
//

#include "stdafx.h"
#include "uebung.h"

#include "uebungDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUebungDoc

IMPLEMENT_DYNCREATE(CUebungDoc, CDocument)

BEGIN_MESSAGE_MAP(CUebungDoc, CDocument)
	//{{AFX_MSG_MAP(CUebungDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUebungDoc Konstruktion/Destruktion

CUebungDoc::CUebungDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CUebungDoc::~CUebungDoc()
{
}

BOOL CUebungDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CUebungDoc Diagnose

#ifdef _DEBUG
void CUebungDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CUebungDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUebungDoc Befehle
