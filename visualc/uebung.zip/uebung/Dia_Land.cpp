// Dia_Land.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "Dia_Land.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite Dia_Land 

IMPLEMENT_DYNCREATE(Dia_Land, CPropertyPage)

Dia_Land::Dia_Land() : CPropertyPage(Dia_Land::IDD)
{
	//{{AFX_DATA_INIT(Dia_Land)
	m_bez = _T("");
	m_iso = _T("");
	m_landid = _T("");
	//}}AFX_DATA_INIT
}

Dia_Land::~Dia_Land()
{
}

void Dia_Land::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Dia_Land)
	DDX_Text(pDX, IDC_BEZ, m_bez);
	DDX_Text(pDX, IDC_ISO, m_iso);
	DDX_Text(pDX, IDC_LANDID, m_landid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Dia_Land, CPropertyPage)
	//{{AFX_MSG_MAP(Dia_Land)
	ON_BN_CLICKED(IDC_BUTTON1, OnAdd)
	ON_BN_CLICKED(IDC_BUTTON2, OnUpdate)
	ON_BN_CLICKED(IDC_BUTTON3, OnDelete)
	ON_BN_CLICKED(IDC_BUTTON4, OnLeft)
	ON_BN_CLICKED(IDC_BUTTON5, OnRight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Dia_Land 

void Dia_Land::OnAdd() 
{
	UpdateData(TRUE);

	land.AddNew();
	DBUpdate(true);
	land.Update();

}

void Dia_Land::DBUpdate(bool toDB)
{
	if (toDB)
	{
		land.m_Bezeichnung = this->m_bez;
		land.m_ISO = m_iso;
	}else
	{
		this->m_bez = land.m_Bezeichnung;
		m_iso = land.m_ISO;
		this->m_landid.Format("%ld",land.m_LandID);
	}
}

void Dia_Land::OnUpdate() 
{
	UpdateData(TRUE);

	land.Edit();
	DBUpdate(true);
	land.Update();
}

void Dia_Land::OnDelete() 
{
	UpdateData(TRUE);
	land.Delete();
	land.Requery();
	DBUpdate(false);
	UpdateData(FALSE);
}

BOOL Dia_Land::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	land.Open();
	DBUpdate(false);
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void Dia_Land::OnLeft() 
{
	land.MovePrev();
	DBUpdate(false);
	UpdateData(FALSE);
}

void Dia_Land::OnRight() 
{
	land.MoveNext();
	DBUpdate(false);
	UpdateData(FALSE);
}
