// LandRec.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "LandRec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// LandRec

IMPLEMENT_DYNAMIC(LandRec, CRecordset)

LandRec::LandRec(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(LandRec)
	m_LandID = 0;
	m_ISO = _T("");
	m_Bezeichnung = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString LandRec::GetDefaultConnect()
{
	return _T("ODBC;DSN=uebung");
}

CString LandRec::GetDefaultSQL()
{
	return _T("[Land]");
}

void LandRec::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(LandRec)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[LandID]"), m_LandID);
	RFX_Text(pFX, _T("[ISO]"), m_ISO);
	RFX_Text(pFX, _T("[Bezeichnung]"), m_Bezeichnung);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose LandRec

#ifdef _DEBUG
void LandRec::AssertValid() const
{
	CRecordset::AssertValid();
}

void LandRec::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
