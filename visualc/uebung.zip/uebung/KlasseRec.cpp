// KlasseRec.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung.h"
#include "KlasseRec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// KlasseRec

IMPLEMENT_DYNAMIC(KlasseRec, CRecordset)

KlasseRec::KlasseRec(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(KlasseRec)
	m_KlasseID = 0;
	m_Raum = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString KlasseRec::GetDefaultConnect()
{
	return _T("ODBC;DSN=uebung");
}

CString KlasseRec::GetDefaultSQL()
{
	return _T("[Klasse]");
}

void KlasseRec::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(KlasseRec)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[KlasseID]"), m_KlasseID);
	RFX_Text(pFX, _T("[Raum]"), m_Raum);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose KlasseRec

#ifdef _DEBUG
void KlasseRec::AssertValid() const
{
	CRecordset::AssertValid();
}

void KlasseRec::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
