// uebung2View.cpp : Implementierung der Klasse CUebung2View
//

#include "stdafx.h"
#include "uebung2.h"

#include "uebung2Doc.h"
#include "uebung2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUebung2View

IMPLEMENT_DYNCREATE(CUebung2View, CView)

BEGIN_MESSAGE_MAP(CUebung2View, CView)
	//{{AFX_MSG_MAP(CUebung2View)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
	// Standard-Druckbefehle
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUebung2View Konstruktion/Destruktion

CUebung2View::CUebung2View()
{
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen,

}

CUebung2View::~CUebung2View()
{
}

BOOL CUebung2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CUebung2View Zeichnen

void CUebung2View::OnDraw(CDC* pDC)
{
	CUebung2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// ZU ERLEDIGEN: Hier Code zum Zeichnen der urspr�nglichen Daten hinzuf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CUebung2View Drucken

BOOL CUebung2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Standardvorbereitung
	return DoPreparePrinting(pInfo);
}

void CUebung2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Zus�tzliche Initialisierung vor dem Drucken hier einf�gen
}

void CUebung2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Hier Bereinigungsarbeiten nach dem Drucken einf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CUebung2View Diagnose

#ifdef _DEBUG
void CUebung2View::AssertValid() const
{
	CView::AssertValid();
}

void CUebung2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CUebung2Doc* CUebung2View::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CUebung2Doc)));
	return (CUebung2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUebung2View Nachrichten-Handler
