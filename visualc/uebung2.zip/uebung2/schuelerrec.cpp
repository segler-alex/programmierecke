// schuelerrec.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "schuelerrec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// schuelerrec

IMPLEMENT_DYNAMIC(schuelerrec, CRecordset)

schuelerrec::schuelerrec(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(schuelerrec)
	m_SchuelerID = 0;
	m_Vorname = _T("");
	m_Nachname = _T("");
	m_Adresse = _T("");
	m_PLZ = _T("");
	m_LandID = 0;
	m_KlasseID = 0;
	m_nFields = 10;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString schuelerrec::GetDefaultConnect()
{
	return _T("ODBC;DSN=uebung");
}

CString schuelerrec::GetDefaultSQL()
{
	return _T("[Schueler]");
}

void schuelerrec::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(schuelerrec)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[SchuelerID]"), m_SchuelerID);
	RFX_Text(pFX, _T("[Vorname]"), m_Vorname);
	RFX_Text(pFX, _T("[Nachname]"), m_Nachname);
	RFX_Date(pFX, _T("[GeborenAm]"), m_GeborenAm);
	RFX_Date(pFX, _T("[EingetretenAm]"), m_EingetretenAm);
	RFX_Date(pFX, _T("[AusgetretenAm]"), m_AusgetretenAm);
	RFX_Text(pFX, _T("[Adresse]"), m_Adresse);
	RFX_Text(pFX, _T("[PLZ]"), m_PLZ);
	RFX_Long(pFX, _T("[LandID]"), m_LandID);
	RFX_Long(pFX, _T("[KlasseID]"), m_KlasseID);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose schuelerrec

#ifdef _DEBUG
void schuelerrec::AssertValid() const
{
	CRecordset::AssertValid();
}

void schuelerrec::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
