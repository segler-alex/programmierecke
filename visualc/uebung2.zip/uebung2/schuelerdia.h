#if !defined(AFX_SCHUELERDIA_H__CF9E42AD_E551_46A3_ABE6_24C69DACC7AA__INCLUDED_)
#define AFX_SCHUELERDIA_H__CF9E42AD_E551_46A3_ABE6_24C69DACC7AA__INCLUDED_

#include "schuelerrec.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// schuelerdia.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld schuelerdia 

class schuelerdia : public CPropertyPage
{
	DECLARE_DYNCREATE(schuelerdia)

// Konstruktion
public:
	schuelerrec schueler;
	schuelerdia();
	~schuelerdia();

// Dialogfelddaten
	//{{AFX_DATA(schuelerdia)
	enum { IDD = IDD_schueler };
	CComboBox	m_land;
	CComboBox	m_klasse;
	CString	m_nachnam;
	CString	m_vornam;
	//}}AFX_DATA



// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(schuelerdia)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(schuelerdia)
	virtual BOOL OnInitDialog();
	afx_msg void Onadd();
	afx_msg void Onedit();
	afx_msg void Ondelete();
	afx_msg void Onleft();
	afx_msg void Onright();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_SCHUELERDIA_H__CF9E42AD_E551_46A3_ABE6_24C69DACC7AA__INCLUDED_
