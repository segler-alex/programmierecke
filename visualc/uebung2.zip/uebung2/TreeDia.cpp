// TreeDia.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "TreeDia.h"
#include "TreeInfoDia.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite TreeDia 

IMPLEMENT_DYNCREATE(TreeDia, CPropertyPage)

TreeDia::TreeDia() : CPropertyPage(TreeDia::IDD)
{
	//{{AFX_DATA_INIT(TreeDia)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT
}

TreeDia::~TreeDia()
{
}

void TreeDia::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(TreeDia)
	DDX_Control(pDX, IDC_TREE1, m_tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(TreeDia, CPropertyPage)
	//{{AFX_MSG_MAP(TreeDia)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten TreeDia 

BOOL TreeDia::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	land.Open();
	schueler.Open();

	while(!land.IsEOF())
	{
		HTREEITEM item = m_tree.InsertItem(land.m_Bezeichnung,-1,-1);

		schueler.m_strFilter.Format("LandID=%ld",land.m_LandID);
		schueler.Requery();
		while(!schueler.IsEOF())
		{
			HTREEITEM sitem = m_tree.InsertItem(schueler.m_Nachname,-1,-1,item);
			m_tree.SetItemData(sitem,schueler.m_SchuelerID);
			schueler.MoveNext();
		}

		land.MoveNext();
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void TreeDia::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	
	// Pr�fen ob ein Item selektiert ist
	// itemNew -> jetzt selektiert
	// itemNew -> vorher selektiert
	if (pNMTreeView->itemNew.hItem != NULL)
	{
		// wenn hintergrundinformation des neu selektierten Items nicht NULL
		// dann handelt es sich um ein item, bei dem wir sie gesetzt haben
		// also um einen schueler
		if (pNMTreeView->itemNew.lParam != NULL)
		{
			TreeInfoDia dia;
			// suchen des sch�lers mit der gemerkten id in der datenbank
			schueler.m_strFilter.Format("schuelerid=%ld",pNMTreeView->itemNew.lParam);
			schueler.Requery();
			// f�llen des dialogs
			dia.m_nname = schueler.m_Nachname;
			dia.m_vname = schueler.m_Vorname;
			// zeigen des dialogs
			dia.DoModal();
			// filter wieder l�schen (where klausel auf leerstring setzen)
			schueler.m_strFilter = "";
			schueler.Requery();
		}
	}
	
	*pResult = 0;
}
