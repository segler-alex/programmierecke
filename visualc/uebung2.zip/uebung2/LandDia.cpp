// LandDia.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "LandDia.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite LandDia 

IMPLEMENT_DYNCREATE(LandDia, CPropertyPage)

LandDia::LandDia() : CPropertyPage(LandDia::IDD)
{
	//{{AFX_DATA_INIT(LandDia)
	m_bez = _T("");
	m_landid = 0;
	//}}AFX_DATA_INIT
}

LandDia::~LandDia()
{
}

void LandDia::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(LandDia)
	DDX_Text(pDX, IDC_BEZ, m_bez);
	DDX_Text(pDX, IDC_LANDID, m_landid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(LandDia, CPropertyPage)
	//{{AFX_MSG_MAP(LandDia)
	ON_BN_CLICKED(IDC_BUTTON2, OnAdd)
	ON_BN_CLICKED(IDC_BUTTON3, OnUpdate)
	ON_BN_CLICKED(IDC_BUTTON4, OnDelete)
	ON_BN_CLICKED(IDC_BUTTON5, OnLeft)
	ON_BN_CLICKED(IDC_BUTTON6, OnRight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten LandDia 



void LandDia::OnAdd() 
{
	land.AddNew();
	UpdateData(TRUE);
	land.m_Bezeichnung = m_bez;
	land.Update();
	land.Requery();
	m_bez = land.m_Bezeichnung;
	m_landid = land.m_LandID;

	UpdateData(FALSE);
}

BOOL LandDia::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	land.Open();

	m_bez = land.m_Bezeichnung;
	m_landid = land.m_LandID;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void LandDia::OnUpdate() 
{
	land.Edit();
	UpdateData(TRUE);
	land.m_Bezeichnung = m_bez;
	land.Update();
}

void LandDia::OnDelete() 
{
	land.Delete();
	land.Requery();
	m_bez = land.m_Bezeichnung;
	m_landid = land.m_LandID;

	UpdateData(FALSE);
}

void LandDia::OnLeft() 
{
	land.MovePrev();
	m_bez = land.m_Bezeichnung;
	m_landid = land.m_LandID;
	UpdateData(FALSE);
}

void LandDia::OnRight() 
{	
	land.MoveNext();
	m_bez = land.m_Bezeichnung;
	m_landid = land.m_LandID;
	UpdateData(FALSE);
}
