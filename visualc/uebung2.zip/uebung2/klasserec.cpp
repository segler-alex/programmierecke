// klasserec.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "klasserec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// klasserec

IMPLEMENT_DYNAMIC(klasserec, CRecordset)

klasserec::klasserec(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(klasserec)
	m_KlasseID = 0;
	m_Raum = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString klasserec::GetDefaultConnect()
{
	return _T("ODBC;DSN=uebung");
}

CString klasserec::GetDefaultSQL()
{
	return _T("[Klasse]");
}

void klasserec::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(klasserec)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[KlasseID]"), m_KlasseID);
	RFX_Text(pFX, _T("[Raum]"), m_Raum);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose klasserec

#ifdef _DEBUG
void klasserec::AssertValid() const
{
	CRecordset::AssertValid();
}

void klasserec::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
