#if !defined(AFX_LANDDIA_H__F44F6695_56CC_4FEF_8DDB_5FB7CCAA60F2__INCLUDED_)
#define AFX_LANDDIA_H__F44F6695_56CC_4FEF_8DDB_5FB7CCAA60F2__INCLUDED_

#include "Landrec.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LandDia.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld LandDia 

class LandDia : public CPropertyPage
{
	DECLARE_DYNCREATE(LandDia)

// Konstruktion
public:
	Landrec land;
	LandDia();
	~LandDia();

// Dialogfelddaten
	//{{AFX_DATA(LandDia)
	enum { IDD = IDD_LAND };
	CString	m_bez;
	int		m_landid;
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(LandDia)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(LandDia)
	afx_msg void OnAdd();
	virtual BOOL OnInitDialog();
	afx_msg void OnUpdate();
	afx_msg void OnDelete();
	afx_msg void OnLeft();
	afx_msg void OnRight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_LANDDIA_H__F44F6695_56CC_4FEF_8DDB_5FB7CCAA60F2__INCLUDED_
