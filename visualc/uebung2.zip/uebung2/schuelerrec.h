#if !defined(AFX_SCHUELERREC_H__44098A8B_D229_4D60_AA47_CD83FC29AE19__INCLUDED_)
#define AFX_SCHUELERREC_H__44098A8B_D229_4D60_AA47_CD83FC29AE19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// schuelerrec.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe schuelerrec 

class schuelerrec : public CRecordset
{
public:
	schuelerrec(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(schuelerrec)

// Feld-/Parameterdaten
	//{{AFX_FIELD(schuelerrec, CRecordset)
	long	m_SchuelerID;
	CString	m_Vorname;
	CString	m_Nachname;
	CTime	m_GeborenAm;
	CTime	m_EingetretenAm;
	CTime	m_AusgetretenAm;
	CString	m_Adresse;
	CString	m_PLZ;
	long	m_LandID;
	long	m_KlasseID;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(schuelerrec)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_SCHUELERREC_H__44098A8B_D229_4D60_AA47_CD83FC29AE19__INCLUDED_
