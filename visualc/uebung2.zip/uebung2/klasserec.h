#if !defined(AFX_KLASSEREC_H__C34A4DD9_C670_4C44_AFED_71FFEECE1F62__INCLUDED_)
#define AFX_KLASSEREC_H__C34A4DD9_C670_4C44_AFED_71FFEECE1F62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// klasserec.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe klasserec 

class klasserec : public CRecordset
{
public:
	klasserec(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(klasserec)

// Feld-/Parameterdaten
	//{{AFX_FIELD(klasserec, CRecordset)
	long	m_KlasseID;
	CString	m_Raum;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(klasserec)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_KLASSEREC_H__C34A4DD9_C670_4C44_AFED_71FFEECE1F62__INCLUDED_
