// uebung2Doc.cpp : Implementierung der Klasse CUebung2Doc
//

#include "stdafx.h"
#include "uebung2.h"

#include "uebung2Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUebung2Doc

IMPLEMENT_DYNCREATE(CUebung2Doc, CDocument)

BEGIN_MESSAGE_MAP(CUebung2Doc, CDocument)
	//{{AFX_MSG_MAP(CUebung2Doc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUebung2Doc Konstruktion/Destruktion

CUebung2Doc::CUebung2Doc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CUebung2Doc::~CUebung2Doc()
{
}

BOOL CUebung2Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CUebung2Doc Serialisierung

void CUebung2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// ZU ERLEDIGEN: Hier Code zum Speichern einf�gen
	}
	else
	{
		// ZU ERLEDIGEN: Hier Code zum Laden einf�gen
	}
}

/////////////////////////////////////////////////////////////////////////////
// CUebung2Doc Diagnose

#ifdef _DEBUG
void CUebung2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CUebung2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUebung2Doc Befehle
