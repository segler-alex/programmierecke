// TreeInfoDia.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "TreeInfoDia.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld TreeInfoDia 


TreeInfoDia::TreeInfoDia(CWnd* pParent /*=NULL*/)
	: CDialog(TreeInfoDia::IDD, pParent)
{
	//{{AFX_DATA_INIT(TreeInfoDia)
	m_nname = _T("");
	m_vname = _T("");
	//}}AFX_DATA_INIT
}


void TreeInfoDia::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(TreeInfoDia)
	DDX_Text(pDX, IDC_NNAME, m_nname);
	DDX_Text(pDX, IDC_VNAME, m_vname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(TreeInfoDia, CDialog)
	//{{AFX_MSG_MAP(TreeInfoDia)
		// HINWEIS: Der Klassen-Assistent f�gt hier Zuordnungsmakros f�r Nachrichten ein
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten TreeInfoDia 
