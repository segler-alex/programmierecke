#if !defined(AFX_TREEDIA_H__0ED7B755_FBD4_4A60_B36E_B69A0529AE65__INCLUDED_)
#define AFX_TREEDIA_H__0ED7B755_FBD4_4A60_B36E_B69A0529AE65__INCLUDED_

#include "Landrec.h"	// Hinzugef�gt von der Klassenansicht
#include "schuelerrec.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TreeDia.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld TreeDia 

class TreeDia : public CPropertyPage
{
	DECLARE_DYNCREATE(TreeDia)

// Konstruktion
public:
	schuelerrec schueler;
	Landrec land;
	TreeDia();
	~TreeDia();

// Dialogfelddaten
	//{{AFX_DATA(TreeDia)
	enum { IDD = IDD_TREE };
	CTreeCtrl	m_tree;
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(TreeDia)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(TreeDia)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TREEDIA_H__0ED7B755_FBD4_4A60_B36E_B69A0529AE65__INCLUDED_
