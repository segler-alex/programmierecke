#if !defined(AFX_TREEINFODIA_H__334AB88B_9EA3_4397_9E8B_207167DD9E52__INCLUDED_)
#define AFX_TREEINFODIA_H__334AB88B_9EA3_4397_9E8B_207167DD9E52__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TreeInfoDia.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld TreeInfoDia 

class TreeInfoDia : public CDialog
{
// Konstruktion
public:
	TreeInfoDia(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(TreeInfoDia)
	enum { IDD = IDD_TREEINFO };
	CString	m_nname;
	CString	m_vname;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(TreeInfoDia)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(TreeInfoDia)
		// HINWEIS: Der Klassen-Assistent f�gt hier Member-Funktionen ein
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TREEINFODIA_H__334AB88B_9EA3_4397_9E8B_207167DD9E52__INCLUDED_
