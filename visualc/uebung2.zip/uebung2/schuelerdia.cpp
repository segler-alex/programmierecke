// schuelerdia.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "schuelerdia.h"
#include "landrec.h"
#include "klasserec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite schuelerdia 

IMPLEMENT_DYNCREATE(schuelerdia, CPropertyPage)

schuelerdia::schuelerdia() : CPropertyPage(schuelerdia::IDD)
{
	//{{AFX_DATA_INIT(schuelerdia)
	m_nachnam = _T("");
	m_vornam = _T("");
	//}}AFX_DATA_INIT
}

schuelerdia::~schuelerdia()
{
}

void schuelerdia::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(schuelerdia)
	DDX_Control(pDX, IDC_Land, m_land);
	DDX_Control(pDX, IDC_Klasse, m_klasse);
	DDX_Text(pDX, IDC_nachnam, m_nachnam);
	DDX_Text(pDX, IDC_vornam, m_vornam);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(schuelerdia, CPropertyPage)
	//{{AFX_MSG_MAP(schuelerdia)
	ON_BN_CLICKED(IDC_BUTTON1, Onadd)
	ON_BN_CLICKED(IDC_BUTTON9, Onedit)
	ON_BN_CLICKED(IDC_BUTTON6, Ondelete)
	ON_BN_CLICKED(IDC_BUTTON7, Onleft)
	ON_BN_CLICKED(IDC_BUTTON8, Onright)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten schuelerdia 

BOOL schuelerdia::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	schueler.Open();

	// erst einmal den aktuellen (ersten) Datensatz dem Benutzer pr�sentieren/anzeigen
	m_vornam = schueler.m_Vorname;
	m_nachnam = schueler.m_Nachname;

	// �ffnenen der Fremdschl�sseltabelle
	Landrec land;
	land.Open();
	// f�lle combobox mit werten aus fremdschl�sseltabelle an
	// als hintergrundinfo wird die id des datensatzes
	// in der fremdschl�sseltabelle mitgespeichert(setitemdata)
	while (!land.IsEOF())
	{
		int index = m_land.AddString(land.m_Bezeichnung);
		m_land.SetItemData(index,land.m_LandID);
		land.MoveNext();
	}
	land.Close();

	// das gleiche f�r die andere fremschl�sseltabelle
	klasserec klasse;
	klasse.Open();
	while(!klasse.IsEOF())
	{
		int index = m_klasse.AddString(klasse.m_Raum);
		m_klasse.SetItemData(index,klasse.m_KlasseID);
		klasse.MoveNext();
	}
	klasse.Close();

	// Anzeigen des landes des sch�lers
	// durchsuchen der combobox nach der landid des sch�lers
	// (im hintergrundinfo gespeichert)
	for (int i=0;i<m_land.GetCount();i++)
	{
		if (m_land.GetItemData(i) == schueler.m_LandID)
			m_land.SetCurSel(i);
	}
	// verschieben des inhalts der dialogvariablen auf die oberfl�che
	UpdateData(FALSE);
	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void schuelerdia::Onadd() 
{
	schueler.AddNew();
	UpdateData(TRUE);
	schueler.m_Vorname = m_vornam;
	schueler.m_Nachname = m_nachnam;
	if (m_land.GetCurSel() != -1)
		schueler.m_LandID = m_land.GetItemData(m_land.GetCurSel());
	if (m_klasse.GetCurSel() != -1)
		schueler.m_KlasseID = m_land.GetItemData(m_klasse.GetCurSel());
	schueler.Update();	
}

void schuelerdia::Onedit() 
{
	schueler.Edit();
	UpdateData(TRUE);
	schueler.m_Vorname = m_vornam;
	schueler.m_Nachname = m_nachnam;
	if (m_land.GetCurSel() != -1)
		schueler.m_LandID = m_land.GetItemData(m_land.GetCurSel());
	if (m_klasse.GetCurSel() != -1)
		schueler.m_KlasseID = m_land.GetItemData(m_klasse.GetCurSel());
	schueler.Update();	
}	



void schuelerdia::Ondelete() 
{
	schueler.Delete();
	schueler.Requery();
	m_vornam = schueler.m_Vorname;
	m_nachnam = schueler.m_Nachname;
	for (int i=0;i<m_land.GetCount();i++)
	{
		if (m_land.GetItemData(i) == schueler.m_LandID)
			m_land.SetCurSel(i);
	}
	UpdateData(FALSE);
}

void schuelerdia::Onleft() 
{
	schueler.MovePrev();
	m_vornam = schueler.m_Vorname;
	m_nachnam = schueler.m_Nachname;
	for (int i=0;i<m_land.GetCount();i++)
	{
		if (m_land.GetItemData(i) == schueler.m_LandID)
			m_land.SetCurSel(i);
	}
	UpdateData(FALSE);

}

void schuelerdia::Onright() 
{
	schueler.MoveNext();
	m_vornam = schueler.m_Vorname;
	m_nachnam = schueler.m_Nachname;
	for (int i=0;i<m_land.GetCount();i++)
	{
		if (m_land.GetItemData(i) == schueler.m_LandID)
			m_land.SetCurSel(i);
	}
	UpdateData(FALSE);

}
