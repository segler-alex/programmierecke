// uebung2Doc.h : Schnittstelle der Klasse CUebung2Doc
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_UEBUNG2DOC_H__6DFA39BD_29DD_404B_985D_1159DD396B3B__INCLUDED_)
#define AFX_UEBUNG2DOC_H__6DFA39BD_29DD_404B_985D_1159DD396B3B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CUebung2Doc : public CDocument
{
protected: // Nur aus Serialisierung erzeugen
	CUebung2Doc();
	DECLARE_DYNCREATE(CUebung2Doc)

// Attribute
public:

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CUebung2Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CUebung2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CUebung2Doc)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_UEBUNG2DOC_H__6DFA39BD_29DD_404B_985D_1159DD396B3B__INCLUDED_)
