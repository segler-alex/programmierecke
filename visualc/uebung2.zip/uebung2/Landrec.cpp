// Landrec.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "uebung2.h"
#include "Landrec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Landrec

IMPLEMENT_DYNAMIC(Landrec, CRecordset)

Landrec::Landrec(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(Landrec)
	m_LandID = 0;
	m_ISO = _T("");
	m_Bezeichnung = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString Landrec::GetDefaultConnect()
{
	return _T("ODBC;DSN=uebung");
}

CString Landrec::GetDefaultSQL()
{
	return _T("[Land]");
}

void Landrec::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(Landrec)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[LandID]"), m_LandID);
	RFX_Text(pFX, _T("[ISO]"), m_ISO);
	RFX_Text(pFX, _T("[Bezeichnung]"), m_Bezeichnung);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose Landrec

#ifdef _DEBUG
void Landrec::AssertValid() const
{
	CRecordset::AssertValid();
}

void Landrec::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
