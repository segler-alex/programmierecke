// RJoin.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "RJoin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// RJoin

IMPLEMENT_DYNAMIC(RJoin, CRecordset)

RJoin::RJoin(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(RJoin)
	m_kunde = _T("");
	m_hausnummer = _T("");
	m_ort = _T("");
	m_strasse = _T("");
	m_land = _T("");
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString RJoin::GetDefaultConnect()
{
	return _T("ODBC;DSN=splitter");
}

CString RJoin::GetDefaultSQL()
{
	return _T("[Adresse],[Land],[Kunde]");
}

void RJoin::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(RJoin)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Kunde].[Name]"), m_kunde);
	RFX_Text(pFX, _T("[Hausnummer]"), m_hausnummer);
	RFX_Text(pFX, _T("[Ort]"), m_ort);
	RFX_Text(pFX, _T("[Strasse]"), m_strasse);
	RFX_Text(pFX, _T("[Land].[Name]"), m_land);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose RJoin

#ifdef _DEBUG
void RJoin::AssertValid() const
{
	CRecordset::AssertValid();
}

void RJoin::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
