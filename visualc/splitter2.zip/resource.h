//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by splitter.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SPLITTER_FORM               101
#define IDR_MAINFRAME                   128
#define IDR_SPLITTTYPE                  129
#define IDD_LAND                        131
#define IDD_KUNDE                       132
#define IDD_ADRESSE                     133
#define IDD_JOIN                        134
#define IDD_TAB                         135
#define IDC_EDIT1                       1000
#define IDVOR                           1001
#define IDZURUECK                       1002
#define IDADD                           1003
#define IDSUCH                          1003
#define IDDEL                           1004
#define IDC_LIST1                       1004
#define IDUPDATE                        1005
#define IDC_TAB1                        1005
#define IDC_EDIT2                       1006
#define IDC_EDIT3                       1007
#define IDC_EDIT4                       1008
#define IDC_EDIT5                       1009
#define IDC_EDIT6                       1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
