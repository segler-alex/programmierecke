#if !defined(AFX_DIAADRESSE_H__08AF5102_6F37_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_DIAADRESSE_H__08AF5102_6F37_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DiaAdresse.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld DiaAdresse 

#include "RAdresse.h"

class DiaAdresse : public CDialog
{
// Konstruktion
public:
	void Update(bool db_to_ctrl);
	DiaAdresse(CWnd* pParent = NULL);   // Standardkonstruktor
	RAdresse rec;

// Dialogfelddaten
	//{{AFX_DATA(DiaAdresse)
	enum { IDD = IDD_ADRESSE };
	CString	m_strasse;
	CString	m_hausnr;
	CString	m_ort;
	CString	m_plz;
	long	m_id;
	long	m_land;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(DiaAdresse)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(DiaAdresse)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnDel();
	afx_msg void OnUpdate();
	afx_msg void OnVor();
	afx_msg void OnZurueck();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIAADRESSE_H__08AF5102_6F37_11D6_818C_000021ECA4DE__INCLUDED_
