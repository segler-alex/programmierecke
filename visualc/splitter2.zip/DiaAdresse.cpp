// DiaAdresse.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "DiaAdresse.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld DiaAdresse 


DiaAdresse::DiaAdresse(CWnd* pParent /*=NULL*/)
	: CDialog(DiaAdresse::IDD, pParent)
{
	//{{AFX_DATA_INIT(DiaAdresse)
	m_strasse = _T("");
	m_hausnr = _T("");
	m_ort = _T("");
	m_plz = _T("");
	m_id = 0;
	m_land = 0;
	//}}AFX_DATA_INIT
}


void DiaAdresse::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DiaAdresse)
	DDX_Text(pDX, IDC_EDIT1, m_strasse);
	DDX_Text(pDX, IDC_EDIT3, m_hausnr);
	DDX_Text(pDX, IDC_EDIT4, m_ort);
	DDX_Text(pDX, IDC_EDIT5, m_plz);
	DDX_Text(pDX, IDC_EDIT2, m_id);
	DDX_Text(pDX, IDC_EDIT6, m_land);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DiaAdresse, CDialog)
	//{{AFX_MSG_MAP(DiaAdresse)
	ON_BN_CLICKED(IDADD, OnAdd)
	ON_BN_CLICKED(IDDEL, OnDel)
	ON_BN_CLICKED(IDUPDATE, OnUpdate)
	ON_BN_CLICKED(IDVOR, OnVor)
	ON_BN_CLICKED(IDZURUECK, OnZurueck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten DiaAdresse 

BOOL DiaAdresse::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	rec.Open();
	Update(true);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void DiaAdresse::OnAdd() 
{
	rec.AddNew();
	Update(false);
	rec.Update();
	rec.Requery();
	Update(true);
}

void DiaAdresse::OnDel() 
{
	rec.Delete();
	rec.Requery();
	Update(true);
}

void DiaAdresse::OnUpdate() 
{
	rec.Edit();
	Update(false);
	rec.Update();
}

void DiaAdresse::OnVor() 
{
	rec.MoveNext();
	if (rec.IsEOF())
		rec.MovePrev();
	Update(true);
}

void DiaAdresse::OnZurueck() 
{
	rec.MovePrev();
	if (rec.IsBOF())
		rec.MoveNext();
	Update(true);
}

void DiaAdresse::Update(bool db_to_ctrl)
{
	if (db_to_ctrl)
	{
		// von der DB in die Membervariablen
		m_hausnr = rec.m_Hausnummer;
		m_id = rec.m_Index;
		m_land = rec.m_Land;
		m_ort = rec.m_Ort;
		m_plz = rec.m_Postleitzahl;
		m_strasse = rec.m_Strasse;
		UpdateData(false);
	}else
	{
		// von den Membervariablen in die DB
		UpdateData(true);
		rec.m_Hausnummer = m_hausnr;
		// Die ID wird von der Datenbank automatisch vergeben
		// desshalb nicht setzen
		// rec.m_Index = m_id;
		rec.m_Land = m_land;
		rec.m_Ort = m_ort;
		rec.m_Postleitzahl = m_plz;
		rec.m_Strasse = m_strasse;
	}
	
}
