// RKunde.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "RKunde.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// RKunde

IMPLEMENT_DYNAMIC(RKunde, CRecordset)

RKunde::RKunde(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(RKunde)
	m_Name = _T("");
	m_Index = 0;
	m_Kundennummer = 0;
	m_Branche = 0;
	m_Umsatzziel = 0;
	m_Adresse = 0;
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString RKunde::GetDefaultConnect()
{
	return _T("ODBC;DSN=splitter");
}

CString RKunde::GetDefaultSQL()
{
	return _T("[Kunde]");
}

void RKunde::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(RKunde)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Long(pFX, _T("[Index]"), m_Index);
	RFX_Long(pFX, _T("[Kundennummer]"), m_Kundennummer);
	RFX_Long(pFX, _T("[Branche]"), m_Branche);
	RFX_Long(pFX, _T("[Umsatzziel]"), m_Umsatzziel);
	RFX_Long(pFX, _T("[Adresse]"), m_Adresse);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose RKunde

#ifdef _DEBUG
void RKunde::AssertValid() const
{
	CRecordset::AssertValid();
}

void RKunde::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
