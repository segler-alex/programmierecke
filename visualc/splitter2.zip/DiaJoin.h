#if !defined(AFX_DIAJOIN_H__08AF5103_6F37_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_DIAJOIN_H__08AF5103_6F37_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DiaJoin.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld DiaJoin 

#include "RJoin.h"

class DiaJoin : public CDialog
{
// Konstruktion
public:
	RJoin rec;
	DiaJoin(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(DiaJoin)
	enum { IDD = IDD_JOIN };
	CListCtrl	m_list;
	CString	m_kunde;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(DiaJoin)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(DiaJoin)
	afx_msg void OnSuch();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIAJOIN_H__08AF5103_6F37_11D6_818C_000021ECA4DE__INCLUDED_
