#if !defined(AFX_TABVIEW_H__08AF5101_6F37_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_TABVIEW_H__08AF5101_6F37_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabView.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Formularansicht CTabView 

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CTabView : public CFormView
{
protected:
	CTabView();           // Dynamische Erstellung verwendet gesch�tzten Konstruktor
	DECLARE_DYNCREATE(CTabView)

// Formulardaten
public:
	//{{AFX_DATA(CTabView)
	enum { IDD = IDD_TAB };
	CTabCtrl	m_tabctrl;
	//}}AFX_DATA

// Attribute
public:

// Operationen
public:
	bool BehandleTastenDruck(MSG* pMsg);
	CDialog* dialoge[4];

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CTabView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	virtual ~CTabView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CTabView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangingTab1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TABVIEW_H__08AF5101_6F37_11D6_818C_000021ECA4DE__INCLUDED_
