// RLand.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "RLand.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// RLand

IMPLEMENT_DYNAMIC(RLand, CRecordset)

RLand::RLand(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(RLand)
	m_Index = 0;
	m_Name = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString RLand::GetDefaultConnect()
{
	return _T("ODBC;DSN=splitter");
}

CString RLand::GetDefaultSQL()
{
	return _T("[Land]");
}

void RLand::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(RLand)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Index]"), m_Index);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose RLand

#ifdef _DEBUG
void RLand::AssertValid() const
{
	CRecordset::AssertValid();
}

void RLand::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
