// TabView.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "TabView.h"

#include "DiaAdresse.h"
#include "DiaJoin.h"
#include "DiaKunde.h"
#include "DiaLand.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabView

IMPLEMENT_DYNCREATE(CTabView, CFormView)

CTabView::CTabView()
	: CFormView(CTabView::IDD)
{
	//{{AFX_DATA_INIT(CTabView)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT
}

CTabView::~CTabView()
{
	for (int i=0;i<4;i++)
		delete dialoge[i];
}

void CTabView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabView)
	DDX_Control(pDX, IDC_TAB1, m_tabctrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabView, CFormView)
	//{{AFX_MSG_MAP(CTabView)
	ON_WM_SIZE()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab1)
	ON_NOTIFY(TCN_SELCHANGING, IDC_TAB1, OnSelchangingTab1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Diagnose CTabView

#ifdef _DEBUG
void CTabView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTabView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CTabView 

void CTabView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// Jeweils anlegen des Speichers f�r den Dialog
	// und anlegen der dahinterliegenden Windows Datenstruktur mit Create
	dialoge[0] = new DiaAdresse();
	dialoge[0]->Create(IDD_ADRESSE,&m_tabctrl);
	m_tabctrl.InsertItem(0,"Adresse");

	dialoge[1] = new DiaJoin();
	dialoge[1]->Create(IDD_JOIN,&m_tabctrl);
	m_tabctrl.InsertItem(1,"Join");

	dialoge[2] = new DiaKunde();
	dialoge[2]->Create(IDD_KUNDE,&m_tabctrl);
	m_tabctrl.InsertItem(2,"Kunde");

	dialoge[3] = new DiaLand();
	dialoge[3]->Create(IDD_LAND,&m_tabctrl);
	m_tabctrl.InsertItem(3,"Land");
}

void CTabView::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);
	
	// Wenn die Fenstergr��e ver�ndert wird, das CTabCtrl anpassen
	if (m_tabctrl.GetSafeHwnd() != NULL)
		m_tabctrl.MoveWindow(0,0,cx,cy);

	CRect rechteck;
	// Ebenso den angezeigten Dialog anpassen
	// Nur wenn CTabCtrl schon oder noch existiert.
	if (m_tabctrl.GetSafeHwnd() != NULL)
	{
		// Gr��e des CTabCtrls holen
		m_tabctrl.GetClientRect(rechteck);
		// Dialog an die Gr��e des Fensters anpassen und anzeigen
		dialoge[0]->SetWindowPos(NULL,rechteck.left+5,rechteck.top+25,rechteck.right-10,rechteck.bottom-30,SWP_SHOWWINDOW);
	}
}

void CTabView::OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int neu;
	CRect rechteck;
	// Nummer der neuen aktivierten Registerkarte holen
	neu = m_tabctrl.GetCurSel();
	// Holen der aktellen Gr��e des Fensters
	m_tabctrl.GetClientRect(rechteck);
	// Dialog an die Gr��e des Fensters anpassen und anzeigen
	dialoge[neu]->SetWindowPos(NULL,rechteck.left+5,rechteck.top+25,rechteck.right-10,rechteck.bottom-30,SWP_SHOWWINDOW);

	*pResult = 0;
}

void CTabView::OnSelchangingTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int alt;
	// Nummer der alten aktivierten Registerkarte holen
	alt = m_tabctrl.GetCurSel();
	// und verstecken
	dialoge[alt]->ShowWindow(SW_HIDE);

	*pResult = 0;
}

bool CTabView::BehandleTastenDruck(MSG *pMsg)
{
	// Wenn die Tasten STRG und TAB gleichzeitig gedr�ckt werden
	if ((pMsg->wParam == VK_TAB) && (GetKeyState(VK_CONTROL) < 0))
	{
		int alt = m_tabctrl.GetCurSel();
		
		int neu;
		// Wenn die Shifttaste gedr�ckt wird
		if (GetKeyState(VK_SHIFT) < 0)
			// eins abziehen
			// mathematischer Trick
			neu = (m_tabctrl.GetCurSel()-1+4)%4;
		else
			// sonst eins dazuz�hlen
			neu = (m_tabctrl.GetCurSel()+1)%4;

		// N�chsten Reiterbutton aktivieren
		m_tabctrl.SetCurSel(neu);
		// Alten Dialog verstecken
		dialoge[alt]->ShowWindow(SW_HIDE);
		// Neuen anzeigen
		CRect rechteck;
		// Holen der aktellen Gr��e des Fensters
		m_tabctrl.GetClientRect(rechteck);
		// Dialog an die Gr��e des Fensters anpassen und anzeigen
		dialoge[neu]->SetWindowPos(NULL,rechteck.left+5,rechteck.top+25,rechteck.right-10,rechteck.bottom-30,SWP_SHOWWINDOW);
	}

	// Dialoge werden normalerweise bei ESC und ENTER geschlossen und zerst�rt
	// um dies zu verhindern leiten wir die Taste einfach nicht weiter
	if ((pMsg->wParam == VK_RETURN) || (pMsg->wParam == VK_ESCAPE))
		return true;
	return false;
}
