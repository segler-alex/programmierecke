#if !defined(AFX_RADRESSE_H__3ABEC788_6360_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_RADRESSE_H__3ABEC788_6360_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RAdresse.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe RAdresse 

class RAdresse : public CRecordset
{
public:
	RAdresse(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(RAdresse)

// Feld-/Parameterdaten
	//{{AFX_FIELD(RAdresse, CRecordset)
	long	m_Index;
	CString	m_Strasse;
	CString	m_Hausnummer;
	CString	m_Ort;
	CString	m_Postleitzahl;
	long	m_Land;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(RAdresse)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_RADRESSE_H__3ABEC788_6360_11D6_818C_000021ECA4DE__INCLUDED_
