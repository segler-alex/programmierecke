#if !defined(AFX_RKUNDE_H__038DB281_635B_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_RKUNDE_H__038DB281_635B_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RKunde.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe RKunde 

class RKunde : public CRecordset
{
public:
	RKunde(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(RKunde)

// Feld-/Parameterdaten
	//{{AFX_FIELD(RKunde, CRecordset)
	CString	m_Name;
	long	m_Index;
	long	m_Kundennummer;
	long	m_Branche;
	long	m_Umsatzziel;
	long	m_Adresse;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(RKunde)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_RKUNDE_H__038DB281_635B_11D6_818C_000021ECA4DE__INCLUDED_
