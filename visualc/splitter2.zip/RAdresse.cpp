// RAdresse.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "RAdresse.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// RAdresse

IMPLEMENT_DYNAMIC(RAdresse, CRecordset)

RAdresse::RAdresse(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(RAdresse)
	m_Index = 0;
	m_Strasse = _T("");
	m_Hausnummer = _T("");
	m_Ort = _T("");
	m_Postleitzahl = _T("");
	m_Land = 0;
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString RAdresse::GetDefaultConnect()
{
	return _T("ODBC;DSN=splitter");
}

CString RAdresse::GetDefaultSQL()
{
	return _T("[Adresse]");
}

void RAdresse::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(RAdresse)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Index]"), m_Index);
	RFX_Text(pFX, _T("[Strasse]"), m_Strasse);
	RFX_Text(pFX, _T("[Hausnummer]"), m_Hausnummer);
	RFX_Text(pFX, _T("[Ort]"), m_Ort);
	RFX_Text(pFX, _T("[Postleitzahl]"), m_Postleitzahl);
	RFX_Long(pFX, _T("[Land]"), m_Land);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Diagnose RAdresse

#ifdef _DEBUG
void RAdresse::AssertValid() const
{
	CRecordset::AssertValid();
}

void RAdresse::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
