#if !defined(AFX_RJOIN_H__3ABEC78A_6360_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_RJOIN_H__3ABEC78A_6360_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RJoin.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe RJoin 

class RJoin : public CRecordset
{
public:
	RJoin(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(RJoin)

// Feld-/Parameterdaten
	//{{AFX_FIELD(RJoin, CRecordset)
	CString	m_kunde;
	CString	m_hausnummer;
	CString	m_ort;
	CString	m_strasse;
	CString	m_land;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(RJoin)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_RJOIN_H__3ABEC78A_6360_11D6_818C_000021ECA4DE__INCLUDED_
