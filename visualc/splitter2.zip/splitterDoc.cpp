// splitterDoc.cpp : Implementierung der Klasse CSplitterDoc
//

#include "stdafx.h"
#include "splitter.h"

#include "splitterDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSplitterDoc

IMPLEMENT_DYNCREATE(CSplitterDoc, CDocument)

BEGIN_MESSAGE_MAP(CSplitterDoc, CDocument)
	//{{AFX_MSG_MAP(CSplitterDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplitterDoc Konstruktion/Destruktion

CSplitterDoc::CSplitterDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CSplitterDoc::~CSplitterDoc()
{
}

BOOL CSplitterDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSplitterDoc Serialisierung

void CSplitterDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// ZU ERLEDIGEN: Hier Code zum Speichern einf�gen
	}
	else
	{
		// ZU ERLEDIGEN: Hier Code zum Laden einf�gen
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSplitterDoc Diagnose

#ifdef _DEBUG
void CSplitterDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSplitterDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSplitterDoc Befehle
