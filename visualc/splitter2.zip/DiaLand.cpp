// DiaLand.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "DiaLand.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld DiaLand 


DiaLand::DiaLand(CWnd* pParent /*=NULL*/)
	: CDialog(DiaLand::IDD, pParent)
{
	//{{AFX_DATA_INIT(DiaLand)
	m_land = _T("");
	m_id = 0;
	//}}AFX_DATA_INIT
}


void DiaLand::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DiaLand)
	DDX_Text(pDX, IDC_EDIT1, m_land);
	DDX_Text(pDX, IDC_EDIT3, m_id);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DiaLand, CDialog)
	//{{AFX_MSG_MAP(DiaLand)
	ON_BN_CLICKED(IDZURUECK, OnZurueck)
	ON_BN_CLICKED(IDVOR, OnVor)
	ON_BN_CLICKED(IDUPDATE, OnUpdate)
	ON_BN_CLICKED(IDDEL, OnDel)
	ON_BN_CLICKED(IDADD, OnAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten DiaLand 

void DiaLand::OnZurueck() 
{
	rec.MovePrev();
	if (rec.IsBOF())
		rec.MoveNext();
	Update(true);
}

void DiaLand::OnVor() 
{
	rec.MoveNext();
	if (rec.IsEOF())
		rec.MovePrev();
	Update(true);
}

void DiaLand::OnUpdate() 
{
	rec.Edit();
	Update(false);
	rec.Update();
}

void DiaLand::OnDel() 
{
	rec.Delete();
	rec.Requery();
	Update(true);
}

void DiaLand::OnAdd() 
{
	rec.AddNew();
	Update(false);
	rec.Update();
	rec.Requery();
	Update(true);
}

BOOL DiaLand::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	rec.Open();
	Update(true);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void DiaLand::Update(bool db_to_ctrl)
{
	if (db_to_ctrl)
	{
		m_id = rec.m_Index;
		m_land = rec.m_Name;
		UpdateData(false);
	}else
	{
		UpdateData(true);
		rec.m_Name = m_land;
	}
}
