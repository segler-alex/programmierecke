// DiaJoin.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "splitter.h"
#include "DiaJoin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld DiaJoin 


DiaJoin::DiaJoin(CWnd* pParent /*=NULL*/)
	: CDialog(DiaJoin::IDD, pParent)
{
	//{{AFX_DATA_INIT(DiaJoin)
	m_kunde = _T("");
	//}}AFX_DATA_INIT
}


void DiaJoin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DiaJoin)
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_EDIT1, m_kunde);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DiaJoin, CDialog)
	//{{AFX_MSG_MAP(DiaJoin)
	ON_BN_CLICKED(IDSUCH, OnSuch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten DiaJoin 

void DiaJoin::OnSuch() 
{
		// Natural Join (jedes mit jedem) verhindern
	rec.m_strFilter = "Kunde.Adresse = Adresse.Index AND Adresse.Land = Land.Index";

	// Schauen, ob etwas im Eingabefeld steht
	UpdateData();
	if (m_kunde != "")
		//Wenn ja, danach suchen
		rec.m_strFilter += " AND Kunde.Name = '"+m_kunde+"'";

	// Recordset aktualisieren ( Suchregel wird angewendet )
	rec.Requery();
	// Alte Items der CListCtrl l�schen
	m_list.DeleteAllItems();
	// Solange Elemente vorhanden
	while (!rec.IsEOF())
	{
		// in CListCtrl einf�gen
		int item = m_list.InsertItem(0,rec.m_kunde,-1);
		m_list.SetItemText(item,1,rec.m_ort);
		m_list.SetItemText(item,2,rec.m_strasse);
		m_list.SetItemText(item,3,rec.m_hausnummer);
		m_list.SetItemText(item,4,rec.m_land);
		// Aktellen Datensatz um eins weitersetzen
		rec.MoveNext();
	}
}

BOOL DiaJoin::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	rec.Open();

	// Tabellen�berschriften setzen
	m_list.InsertColumn(0,"Kunde",LVCFMT_LEFT,60);
	m_list.InsertColumn(1,"Ort",LVCFMT_LEFT,60);
	m_list.InsertColumn(2,"Strasse",LVCFMT_LEFT,80);
	m_list.InsertColumn(3,"Hausnr",LVCFMT_LEFT,40);
	m_list.InsertColumn(4,"Land",LVCFMT_LEFT,80);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}
