#if !defined(AFX_RLAND_H__038DB282_635B_11D6_818C_000021ECA4DE__INCLUDED_)
#define AFX_RLAND_H__038DB282_635B_11D6_818C_000021ECA4DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RLand.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Satzgruppe RLand 

class RLand : public CRecordset
{
public:
	RLand(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(RLand)

// Feld-/Parameterdaten
	//{{AFX_FIELD(RLand, CRecordset)
	long	m_Index;
	CString	m_Name;
	//}}AFX_FIELD


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(RLand)
	public:
	virtual CString GetDefaultConnect();    // Standard-Verbindungszeichenfolge
	virtual CString GetDefaultSQL();    // Standard-SQL f�r Satzgruppe
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_RLAND_H__038DB282_635B_11D6_818C_000021ECA4DE__INCLUDED_
