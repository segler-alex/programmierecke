// UndoObject.cpp: Implementierung der Klasse UndoObject.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "UndoObject.h"
#include "ZeichenObject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

UndoObject::UndoObject()
{
	this->undoart=-1;
	this->undonum=-1;
}

UndoObject::~UndoObject()
{

}

void UndoObject::undo(ZeichenObject *ob)
{
	if (undoart==1){
		ob->setpoint(this->variables[0],this->variables[1],true);
		this->variables[0]=this->variables[0]*(-1);
		this->variables[1]=this->variables[1]*(-1);
	}
	if (undoart==2){
		this->variables[0]=ob->setColor(this->variables[0]);
	}
	if (undoart==3){
	}
}

void UndoObject::closeandsave(int vars[10], ZeichenObject *ob, int undonum)
{
	for (int i=0;i<10;i++)
		this->variables[i]=vars[i];
	this->undonum=undonum;
	ob->undoliste.Add(this);
}

UndoObject::UndoObject(int art)
{
	this->undoart=art;
}
