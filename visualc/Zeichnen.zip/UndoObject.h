// UndoObject.h: Schnittstelle f�r die Klasse UndoObject.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UNDOOBJECT_H__6A491DE1_ECDA_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_UNDOOBJECT_H__6A491DE1_ECDA_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ZeichenObject.h"

class UndoObject : public CObject  
{
	/*undoart	1: Verschieben
				2: Umverben
				3: L�schen
	*/
public:
	UndoObject(int art);
	int undoart;
	void closeandsave(int vars[10], ZeichenObject* ob, int undonum);
	void undo(ZeichenObject* ob);
	int undonum;
	UndoObject();
	virtual ~UndoObject();

private:
	int variables[10];
};

#endif // !defined(AFX_UNDOOBJECT_H__6A491DE1_ECDA_11D5_BD76_0040F41E1AF0__INCLUDED_)
