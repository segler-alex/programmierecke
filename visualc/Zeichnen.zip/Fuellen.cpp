// Fuellen.cpp: Implementierung der Klasse Fuellen.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "Fuellen.h"
#include "UndoObject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(Fuellen,ZeichenObject,1)

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

Fuellen::Fuellen()
{
}

Fuellen::~Fuellen()
{
	for (int i=0;i<undoliste.GetSize();i++)
		delete undoliste[i];
	undoliste.RemoveAll();
}

void Fuellen::print(CDC *pDC)
{
	CBrush* brush=new CBrush(color);
	CBrush* oldbrush=pDC->SelectObject(brush);
	pDC->ExtFloodFill(x,y,pDC->GetPixel(x,y),FLOODFILLSURFACE);
	pDC->SelectObject(oldbrush);
	delete brush;
}

Fuellen::Fuellen(int x, int y, int color)
{
	this->x=x;
	this->y=y;
	this->color=color;
}

void Fuellen::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar<<x<<y<<color<<num;
	}
	else
	{
		ar>>x>>y>>color>>num;
	}
}

void Fuellen::setpoint(int x, int y, boolean add)
{
	this->x=x;
	this->y=y;
}

boolean Fuellen::IsPoint(int ex, int ey, int ecolor)
{
	return false;
}

boolean Fuellen::iscolorchage(ZeichenObject *ob, int undonum)
{
	if (ob!=NULL){
		UndoObject* undoi=new UndoObject(2);
		int h[10];
		h[0]=ob->setColor(color);
		undoi->closeandsave(h,ob,undonum);
		return true;
	}
	return false;
}
