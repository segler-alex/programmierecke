// ZeichnenView.h : Schnittstelle der Klasse CZeichnenView
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZEICHNENVIEW_H__120AE1AD_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_ZEICHNENVIEW_H__120AE1AD_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ZeichenObject.h"
#include "Menudialog.h"
#include "UndoObject.h"

class CZeichnenView : public CView
{
protected: // Nur aus Serialisierung erzeugen
	CZeichnenView();
	DECLARE_DYNCREATE(CZeichnenView)

// Attribute
public:
	CZeichnenDoc* GetDocument();

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CZeichnenView)
	public:
	virtual void OnDraw(CDC* pDC);  // �berladen zum Zeichnen dieser Ansicht
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementierung
public:
	UndoObject* undoi;
	ZeichenObject *GetZeichenObject(int ex, int ey);
	virtual ~CZeichnenView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CZeichnenView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnButtongerade();
	afx_msg void OnButtonkreis();
	afx_msg void OnButtonlinie();
	afx_msg void OnButtonrechteck();
	afx_msg void OnButtonblack();
	afx_msg void OnButtonblue();
	afx_msg void OnButtongreen();
	afx_msg void OnButtonkreis2();
	afx_msg void OnButtonrechteck2();
	afx_msg void OnButtonred();
	afx_msg void OnButtonyellow();
	afx_msg void OnStrichdicke1pt();
	afx_msg void OnStrichdicke6pt();
	afx_msg void OnStrichdicke5pt();
	afx_msg void OnStrichdicke4pt();
	afx_msg void OnStrichdicke3pt();
	afx_msg void OnStrichdicke2pt();
	afx_msg void OnStrichartStrichliert();
	afx_msg void OnStrichartStrich();
	afx_msg void OnStrichartPunktstrich();
	afx_msg void OnStrichartPunktiert();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnButtonback();
	afx_msg void OnUpdateButtongerade(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonkreis(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonkreis2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonlinie(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonrechteck(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonrechteck2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonred(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonyellow(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtongreen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonblue(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonblack(CCmdUI* pCmdUI);
	afx_msg void OnButtonfill();
	afx_msg void OnUpdateButtonfill(CCmdUI* pCmdUI);
	afx_msg void OnButtonbehind();
	afx_msg void OnButtonfront();
	afx_msg void OnUpdateStrichartPunktiert(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichartPunktstrich(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichartStrich(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichartStrichliert(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichdicke2pt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichdicke3pt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichdicke4pt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichdicke5pt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichdicke6pt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStrichdicke1pt(CCmdUI* pCmdUI);
	afx_msg void OnButtondialog();
	afx_msg void OnButtonzeiger();
	afx_msg void OnUpdateButtonzeiger(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int firsty;
	int firstx;
	int oldy;
	int oldx;
	Menudialog* dialogi;
	CString* GetStatusText();
	boolean ispressed;
	ZeichenObject* objecti;
	int objectart;
	int art;
	int y;
	int x;
	int dicke;
	int color;
	int muster;
};

#ifndef _DEBUG  // Testversion in ZeichnenView.cpp
inline CZeichnenDoc* CZeichnenView::GetDocument()
   { return (CZeichnenDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_ZEICHNENVIEW_H__120AE1AD_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
