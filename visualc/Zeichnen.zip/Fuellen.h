// Fuellen.h: Schnittstelle f�r die Klasse Fuellen.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FUELLEN_H__0E19BC8A_DC5B_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_FUELLEN_H__0E19BC8A_DC5B_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ZeichenObject.h"

class Fuellen : public ZeichenObject  
{
public:
	boolean iscolorchage(ZeichenObject* ob, int undonum);
	boolean IsPoint(int ex, int ey, int ecolor);
	void setpoint(int x, int y, boolean add);
	DECLARE_SERIAL(Fuellen)
	void Serialize(CArchive& ar);
	Fuellen(int x, int y, int color);
	void print(CDC *pDC);
	Fuellen();
	virtual ~Fuellen();

private:
	int y;
	int x;
};

#endif // !defined(AFX_FUELLEN_H__0E19BC8A_DC5B_11D5_BD76_0040F41E1AF0__INCLUDED_)
