// Zeichnen.h : Haupt-Header-Datei f�r die Anwendung ZEICHNEN
//

#if !defined(AFX_ZEICHNEN_H__120AE1A3_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_ZEICHNEN_H__120AE1A3_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CZeichnenApp:
// Siehe Zeichnen.cpp f�r die Implementierung dieser Klasse
//

class CZeichnenApp : public CWinApp
{
public:
	CZeichnenApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CZeichnenApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung
	//{{AFX_MSG(CZeichnenApp)
	afx_msg void OnAppAbout();
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_ZEICHNEN_H__120AE1A3_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
