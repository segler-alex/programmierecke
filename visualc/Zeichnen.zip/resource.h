//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Zeichnen.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ZEICHNTYPE                  129
#define IDD_DIALOG1                     131
#define IDC_LIST1                       1001
#define IDC_LIST2                       1002
#define IDC_COMBO2                      1004
#define IDC_LIST3                       1007
#define ID_BUTTONRECHTECK               32771
#define ID_BUTTONKREIS                  32772
#define ID_BUTTONGERADE                 32773
#define ID_BUTTONLINIE                  32774
#define ID_STRICHDICKE1PT               32785
#define ID_STRICHDICKE_2PT              32786
#define ID_STRICHDICKE_3PT              32787
#define ID_STRICHDICKE_4PT              32788
#define ID_STRICHDICKE_5PT              32789
#define ID_STRICHDICKE_6PT              32790
#define ID_STRICHART_STRICH             32791
#define ID_STRICHART_STRICHLIERT        32792
#define ID_STRICHART_PUNKTSTRICH        32793
#define ID_BUTTONKREIS2                 32794
#define ID_BUTTONRECHTECK2              32795
#define ID_BUTTONRED                    32796
#define ID_BUTTONYELLOW                 32797
#define ID_BUTTONBLUE                   32798
#define ID_BUTTONGREEN                  32799
#define ID_BUTTONBLACK                  32800
#define ID_STRICHART_PUNKTIERT          32801
#define ID_BUTTONBACK                   32802
#define ID_BUTTONFILL                   32803
#define ID_BUTTONBEHIND                 32804
#define ID_BUTTONFRONT                  32805
#define ID_BUTTONDIALOG                 32806
#define ID_BUTTONZEIGER                 32807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32808
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
