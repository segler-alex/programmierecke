// ZeichenObject.cpp: Implementierung der Klasse ZeichenObject.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "ZeichenObject.h"
#include "UndoObject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(ZeichenObject,CObject,1)

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

ZeichenObject::ZeichenObject()
{

}

ZeichenObject::~ZeichenObject()
{
	for (int i=0;i<undoliste.GetSize();i++)
		delete undoliste[i];
	undoliste.RemoveAll();
}


void ZeichenObject::print(CDC *pDC)
{

}

void ZeichenObject::setpoint(int x, int y, boolean add)
{

}


void ZeichenObject::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar<<num<<color;
	}
	else
	{
		ar>>num>>color;
	}
}

boolean ZeichenObject::IsPoint(int ex, int ey, int ecolor)
{
	return false;
}

int ZeichenObject::setColor(int newcolor)
{
	int h=color;
	color=newcolor;
	return h;
}

void ZeichenObject::setnum(int newnum)
{
	this->num=newnum;
}

int ZeichenObject::getHighestUndonum()
{
	int h=-1;
	for (int i=0;i<undoliste.GetSize();i++)
		if (((UndoObject*)undoliste[i])->undonum>h)
			h=((UndoObject*)undoliste[i])->undonum;
	return h;
}

void ZeichenObject::undoLastAction(int undonum2)
{
	if (undoliste.GetSize()>0){
		int h=-1,h2;
		for (int i=0;i<undoliste.GetSize();i++){
			if (((UndoObject*) undoliste[i])->undonum>h){
				h=((UndoObject*)undoliste[i])->undonum;
				h2=i;
			}
		}
		UndoObject* ob=(UndoObject*)undoliste[h2];
		ob->undo(this);
		undoliste.RemoveAt(h2,1);
		delete ob;
	}
}

void ZeichenObject::getPoints(int points[4])
{

}
