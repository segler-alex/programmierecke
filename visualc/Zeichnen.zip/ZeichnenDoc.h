// ZeichnenDoc.h : Schnittstelle der Klasse CZeichnenDoc
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZEICHNENDOC_H__120AE1AB_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_ZEICHNENDOC_H__120AE1AB_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CZeichnenDoc : public CDocument
{
protected: // Nur aus Serialisierung erzeugen
	CZeichnenDoc();
	DECLARE_DYNCREATE(CZeichnenDoc)

// Attribute
public:

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CZeichnenDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementierung
public:
	int undonum2;
	int undonum;
	CObject* DeleteLastObject();
	int getlastElementPosition();
	int number;
	CObArray liste;
	virtual ~CZeichnenDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CZeichnenDoc)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_ZEICHNENDOC_H__120AE1AB_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
