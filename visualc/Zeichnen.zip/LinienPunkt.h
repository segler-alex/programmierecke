// LinienPunkt.h: Schnittstelle f�r die Klasse LinienPunkt.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINIENPUNKT_H__120AE1BA_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_LINIENPUNKT_H__120AE1BA_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class LinienPunkt : public CObject  
{
public:
	void setpoint(int ex, int ey, boolean add);
	boolean IsPoint(int ex, int ey, int ex2, int ey2, int dicke);
	DECLARE_SERIAL(LinienPunkt)
	void Serialize(CArchive& ar);
	CPoint* getpoint();
	LinienPunkt(int x, int y);
	void print(CDC *pDC, int ex, int ey);
	LinienPunkt();
	virtual ~LinienPunkt();

private:
	int y;
	int x;
};

#endif // !defined(AFX_LINIENPUNKT_H__120AE1BA_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
