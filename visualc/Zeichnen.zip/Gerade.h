// Gerade.h: Schnittstelle f�r die Klasse Gerade.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GERADE_H__120AE1B8_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_GERADE_H__120AE1B8_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ZeichenObject.h"

class Gerade : public ZeichenObject  
{
public:
	boolean IsPoint(int ex, int ey, int ecolor);
	DECLARE_SERIAL(Gerade)
	void Serialize(CArchive& ar);
	void setpoint(int x, int y, boolean add);
	Gerade(int x1, int y1, int x2, int y2, int dicke, int color, int muster);
	void print(CDC *pDC);
	Gerade();
	virtual ~Gerade();

private:
	int muster;
	int dicke;
	int y2;
	int x2;
	int y1;
	int x1;
};

#endif // !defined(AFX_GERADE_H__120AE1B8_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
