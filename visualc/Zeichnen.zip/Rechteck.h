// Rechteck.h: Schnittstelle f�r die Klasse Rechteck.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECHTECK_H__120AE1B6_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_RECHTECK_H__120AE1B6_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ZeichenObject.h"

class Rechteck : public ZeichenObject  
{
public:
	boolean IsPoint(int ex, int ey, int ecolor);
	DECLARE_SERIAL(Rechteck)
	void Serialize(CArchive& ar);
	void setpoint(int x, int y, boolean add);
	Rechteck(int x1, int y1, int x2, int y2, int dicke, int color, int muster);
	void print(CDC *pDC);
	
	Rechteck();
	virtual ~Rechteck();

private:
	int dicke;
	int muster;
	int y2;
	int y1;
	int x2;
	int x1;
};

#endif // !defined(AFX_RECHTECK_H__120AE1B6_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
