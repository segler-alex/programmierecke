// Kreis.h: Schnittstelle f�r die Klasse Kreis.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KREIS_H__120AE1B7_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_KREIS_H__120AE1B7_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ZeichenObject.h"

class Kreis : public ZeichenObject  
{
public:
	boolean IsPoint(int ex, int ey, int ecolor);
	DECLARE_SERIAL(Kreis)
	void Serialize(CArchive& ar);
	void setpoint(int x, int y, boolean add);
	Kreis(int x1, int y1, int x2, int y2, int dicke, int color, int muster);
	void print(CDC *pDC);
	Kreis();
	virtual ~Kreis();
private:
	int dicke;
	int muster;
	int y2;
	int y1;
	int x2;
	int x1;
};

#endif // !defined(AFX_KREIS_H__120AE1B7_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
