// Gerade.cpp: Implementierung der Klasse Gerade.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "Gerade.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(Gerade,ZeichenObject,1)

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

Gerade::Gerade()
{
}

Gerade::~Gerade()
{
	for (int i=0;i<undoliste.GetSize();i++)
		delete undoliste[i];
	undoliste.RemoveAll();
}


void Gerade::print(CDC *pDC)
{
 CPen* pen=new CPen(muster,dicke,color);
 CPen* oldpen=pDC->SelectObject(pen);

 pDC->MoveTo(x1,y1);
 pDC->LineTo(x2,y2);

 pDC->SelectObject(oldpen);
 delete pen;
}

Gerade::Gerade(int x1, int y1, int x2, int y2, int dicke, int color, int muster)
{
	this->x1=x1;
	this->x2=x2;
	this->y1=y1;
	this->y2=y2;
	this->color=color;
	this->muster=muster;
	this->dicke=dicke;
}

void Gerade::setpoint(int x, int y, boolean add)
{
	if (!add){
		this->x2=x;
		this->y2=y;
	}
	else{
	 x1=x1+x;
	 x2=x2+x;
	 y1=y1+y;
	 y2=y2+y;
	}
}

void Gerade::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar<<x1<<y1<<x2<<y2<<color<<muster<<dicke<<num;
	}
	else
	{
		ar>>x1>>y1>>x2>>y2>>color>>muster>>dicke>>num;
	}
}

boolean Gerade::IsPoint(int ex, int ey, int ecolor)
{
	boolean hx,hy;
	int h;
	for(int i=-(dicke/2);i<=(dicke/2);i++){
		hx=false;hy=false;
		h=((x2-x1)*(ey+i-y1))-((ex-x1)*(y2-y1));
		if ((h>=-0.2*(ey+i-y1)*(y2-y1))&&(h<=0.2*(ey+i-y1)*(y2-y1))){
			if ((ex>=x1)&&(ex<=x2)) hx=true;
			else
				if ((ex<=x1)&&(ex>=x2)) hx=true;
			if ((ey>=y1)&&(ey<=y2)) hy=true;
			else
				if ((ey<=y1)&&(ey>=y2)) hy=true;
		}
		if (hy&&hx&&color==ecolor)
			return true;
		hx=false;hy=false;
		h=((x2-x1)*(ey-y1))-((ex+i-x1)*(y2-y1));
		if ((h>=-0.2*(ey-y1)*(y2-y1))&&(h<=0.2*(ey-y1)*(y2-y1))){
			if ((ex>=x1)&&(ex<=x2)) hx=true;
			else
				if ((ex<=x1)&&(ex>=x2)) hx=true;
			if ((ey>=y1)&&(ey<=y2)) hy=true;
			else
				if ((ey<=y1)&&(ey>=y2)) hy=true;
		}
		if (hy&&hx&&color==ecolor)
			return true;
	}
	return false;
}
