// ZeichnenView.cpp : Implementierung der Klasse CZeichnenView
//

#include "stdafx.h"
#include "Zeichnen.h"

#include "ZeichnenDoc.h"
#include "ZeichnenView.h"
#include "ZeichenObject.h"
#include "Rechteck.h"
#include "Kreis.h"
#include "Gerade.h"
#include "Linie.h"
#include "Fuellen.h"
#include "MainFrm.h"
#include "UndoObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZeichnenView

IMPLEMENT_DYNCREATE(CZeichnenView, CView)

BEGIN_MESSAGE_MAP(CZeichnenView, CView)
	//{{AFX_MSG_MAP(CZeichnenView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_BUTTONGERADE, OnButtongerade)
	ON_COMMAND(ID_BUTTONKREIS, OnButtonkreis)
	ON_COMMAND(ID_BUTTONLINIE, OnButtonlinie)
	ON_COMMAND(ID_BUTTONRECHTECK, OnButtonrechteck)
	ON_COMMAND(ID_BUTTONBLACK, OnButtonblack)
	ON_COMMAND(ID_BUTTONBLUE, OnButtonblue)
	ON_COMMAND(ID_BUTTONGREEN, OnButtongreen)
	ON_COMMAND(ID_BUTTONKREIS2, OnButtonkreis2)
	ON_COMMAND(ID_BUTTONRECHTECK2, OnButtonrechteck2)
	ON_COMMAND(ID_BUTTONRED, OnButtonred)
	ON_COMMAND(ID_BUTTONYELLOW, OnButtonyellow)
	ON_COMMAND(ID_STRICHDICKE1PT, OnStrichdicke1pt)
	ON_COMMAND(ID_STRICHDICKE_6PT, OnStrichdicke6pt)
	ON_COMMAND(ID_STRICHDICKE_5PT, OnStrichdicke5pt)
	ON_COMMAND(ID_STRICHDICKE_4PT, OnStrichdicke4pt)
	ON_COMMAND(ID_STRICHDICKE_3PT, OnStrichdicke3pt)
	ON_COMMAND(ID_STRICHDICKE_2PT, OnStrichdicke2pt)
	ON_COMMAND(ID_STRICHART_STRICHLIERT, OnStrichartStrichliert)
	ON_COMMAND(ID_STRICHART_STRICH, OnStrichartStrich)
	ON_COMMAND(ID_STRICHART_PUNKTSTRICH, OnStrichartPunktstrich)
	ON_COMMAND(ID_STRICHART_PUNKTIERT, OnStrichartPunktiert)
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_BUTTONBACK, OnButtonback)
	ON_UPDATE_COMMAND_UI(ID_BUTTONGERADE, OnUpdateButtongerade)
	ON_UPDATE_COMMAND_UI(ID_BUTTONKREIS, OnUpdateButtonkreis)
	ON_UPDATE_COMMAND_UI(ID_BUTTONKREIS2, OnUpdateButtonkreis2)
	ON_UPDATE_COMMAND_UI(ID_BUTTONLINIE, OnUpdateButtonlinie)
	ON_UPDATE_COMMAND_UI(ID_BUTTONRECHTECK, OnUpdateButtonrechteck)
	ON_UPDATE_COMMAND_UI(ID_BUTTONRECHTECK2, OnUpdateButtonrechteck2)
	ON_UPDATE_COMMAND_UI(ID_BUTTONRED, OnUpdateButtonred)
	ON_UPDATE_COMMAND_UI(ID_BUTTONYELLOW, OnUpdateButtonyellow)
	ON_UPDATE_COMMAND_UI(ID_BUTTONGREEN, OnUpdateButtongreen)
	ON_UPDATE_COMMAND_UI(ID_BUTTONBLUE, OnUpdateButtonblue)
	ON_UPDATE_COMMAND_UI(ID_BUTTONBLACK, OnUpdateButtonblack)
	ON_COMMAND(ID_BUTTONFILL, OnButtonfill)
	ON_UPDATE_COMMAND_UI(ID_BUTTONFILL, OnUpdateButtonfill)
	ON_COMMAND(ID_BUTTONBEHIND, OnButtonbehind)
	ON_COMMAND(ID_BUTTONFRONT, OnButtonfront)
	ON_UPDATE_COMMAND_UI(ID_STRICHART_PUNKTIERT, OnUpdateStrichartPunktiert)
	ON_UPDATE_COMMAND_UI(ID_STRICHART_PUNKTSTRICH, OnUpdateStrichartPunktstrich)
	ON_UPDATE_COMMAND_UI(ID_STRICHART_STRICH, OnUpdateStrichartStrich)
	ON_UPDATE_COMMAND_UI(ID_STRICHART_STRICHLIERT, OnUpdateStrichartStrichliert)
	ON_UPDATE_COMMAND_UI(ID_STRICHDICKE_2PT, OnUpdateStrichdicke2pt)
	ON_UPDATE_COMMAND_UI(ID_STRICHDICKE_3PT, OnUpdateStrichdicke3pt)
	ON_UPDATE_COMMAND_UI(ID_STRICHDICKE_4PT, OnUpdateStrichdicke4pt)
	ON_UPDATE_COMMAND_UI(ID_STRICHDICKE_5PT, OnUpdateStrichdicke5pt)
	ON_UPDATE_COMMAND_UI(ID_STRICHDICKE_6PT, OnUpdateStrichdicke6pt)
	ON_UPDATE_COMMAND_UI(ID_STRICHDICKE1PT, OnUpdateStrichdicke1pt)
	ON_COMMAND(ID_BUTTONDIALOG, OnButtondialog)
	ON_COMMAND(ID_BUTTONZEIGER, OnButtonzeiger)
	ON_UPDATE_COMMAND_UI(ID_BUTTONZEIGER, OnUpdateButtonzeiger)
	//}}AFX_MSG_MAP
	// Standard-Druckbefehle
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZeichnenView Konstruktion/Destruktion

CZeichnenView::CZeichnenView()
{
	color=RGB(0,0,0);
	dicke=1;
	objectart=0;
	muster=100;
	art=PS_SOLID;
	objecti=NULL;
	undoi=NULL;
	ispressed=false;
	dialogi=new Menudialog();
	oldx=0;
	oldy=0;
}

CZeichnenView::~CZeichnenView()
{
	if (objecti!=NULL)
		delete objecti;
}

BOOL CZeichnenView::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CZeichnenView Zeichnen

extern theApp;
void CZeichnenView::OnDraw(CDC* pDC)
{
	CZeichnenDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	for (int i=0;i<pDoc->liste.GetSize();i++)
		((ZeichenObject*)pDoc->liste[i])->print(pDC);
	if (objecti!=NULL)
		objecti->print(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CZeichnenView Drucken

BOOL CZeichnenView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Standardvorbereitung
	return DoPreparePrinting(pInfo);
}

void CZeichnenView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Zus�tzliche Initialisierung vor dem Drucken hier einf�gen
}

void CZeichnenView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Hier Bereinigungsarbeiten nach dem Drucken einf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CZeichnenView Diagnose

#ifdef _DEBUG
void CZeichnenView::AssertValid() const
{
	CView::AssertValid();
}

void CZeichnenView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CZeichnenDoc* CZeichnenView::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CZeichnenDoc)));
	return (CZeichnenDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZeichnenView Nachrichten-Handler

void CZeichnenView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CView::OnLButtonDown(nFlags, point);
	this->x=point.x;
	this->y=point.y;
	this->firstx=point.x;
	this->firsty=point.y;
	if (objecti==NULL){
		switch(objectart){
		case 0:{objecti=new Rechteck(x,y,point.x,point.y,dicke,color,muster);break;}
		case 1:{objecti=new Gerade(x,y,x,y,dicke,color,art);break;}
		case 2:{objecti=new Kreis(x,y,x,y,dicke,color,muster);break;}
		case 3:{objecti=new Linie(x,y,dicke,color,art);break;}
		case 4:{objecti=new Fuellen(x,y,color);break;}
		case 5:{objecti=GetZeichenObject(x,y);break;}
		break;
		}
	}
	ispressed=true;
}

void CZeichnenView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CView::OnLButtonUp(nFlags, point);

	if (objecti!=NULL){
		if (objectart==4){
			if (!(((Fuellen*)objecti)->iscolorchage(this->GetZeichenObject(point.x,point.y),GetDocument()->undonum))){
				objecti->setnum(GetDocument()->number);
				GetDocument()->number++;
			}
			else 
				delete objecti;
		}
		else{
			objecti->setnum(GetDocument()->number);
			GetDocument()->number++;
		}
		if (objectart!=5){
			if (objectart!=4)
				GetDocument()->liste.Add(objecti);
		}
		else{
			this->undoi=new UndoObject(1);
			int h[10];
			h[0]=firstx-point.x;
			h[1]=firsty-point.y;
			//CString* name=new CString();
			//name->Format("%d, %d, %d, %d, %d, %d",firstx, firsty, point.x,point.y,h[0],h[1]);
			//AfxMessageBox(name->operator LPCTSTR());
			this->undoi->closeandsave(h,objecti,GetDocument()->undonum);
			GetDocument()->undonum++;
			this->undoi=NULL;
		}
	}
	objecti=NULL;
	ispressed=false;
	this->Invalidate(true);
}

void CZeichnenView::OnButtongerade() 
{
	objectart=1;
}

void CZeichnenView::OnButtonkreis() 
{
	muster=100;
	objectart=2;	
}

void CZeichnenView::OnButtonlinie() 
{
	objectart=3;	
}

void CZeichnenView::OnButtonrechteck() 
{
	muster=100;
	objectart=0;
}

void CZeichnenView::OnButtonblack() 
{
	color=RGB(0,0,0);
}

void CZeichnenView::OnButtonblue() 
{
	color=RGB(0,0,200);
}

void CZeichnenView::OnButtongreen() 
{
	color=RGB(0,200,0);
}

void CZeichnenView::OnButtonkreis2() 
{
	muster=0;
	objectart=2;
}

void CZeichnenView::OnButtonrechteck2() 
{
	muster=0;
	objectart=0;
}

void CZeichnenView::OnButtonred() 
{
	color=RGB(200,0,0);
}

void CZeichnenView::OnButtonyellow() 
{
	color=RGB(250,250,0);
}

void CZeichnenView::OnStrichdicke1pt() 
{
	dicke=1;
}

void CZeichnenView::OnStrichdicke6pt() 
{
	dicke=6;
}

void CZeichnenView::OnStrichdicke5pt() 
{
	dicke=5;
}

void CZeichnenView::OnStrichdicke4pt() 
{
	dicke=4;
}

void CZeichnenView::OnStrichdicke3pt() 
{
	dicke=3;
}

void CZeichnenView::OnStrichdicke2pt() 
{
	dicke=2;
}

void CZeichnenView::OnStrichartStrichliert() 
{
	art=PS_DASH;
}

void CZeichnenView::OnStrichartStrich() 
{
	art=PS_SOLID;
}

void CZeichnenView::OnStrichartPunktstrich() 
{
	art=PS_DASHDOT;
}

void CZeichnenView::OnStrichartPunktiert() 
{
	art=PS_DOT;
}

void CZeichnenView::OnMouseMove(UINT nFlags, CPoint point) 
{
	CView::OnMouseMove(nFlags, point);
	if ((ispressed)&&(objecti!=NULL)){
		if (objectart!=5)
			objecti->setpoint(point.x,point.y,false);
		else
			objecti->setpoint(point.x-oldx,point.y-oldy,true);
		this->Invalidate(true);
	}
	else 
		if ((ispressed)&&(objectart==5))
			objecti=GetZeichenObject(point.x,point.y);
	((CMainFrame*)AfxGetApp()->m_pMainWnd)->m_wndStatusBar.SetPaneText(0,GetStatusText()->operator LPCTSTR(),true);
	oldx=point.x;
	oldy=point.y;
}

void CZeichnenView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CView::OnRButtonDown(nFlags, point);
	if (ispressed){
		if (objectart!=5)
			delete objecti;
		objecti=NULL;
	}
}

void CZeichnenView::OnButtonback() 
{
	int h=-1,h2,h3=-1;
	for (int i=0;i<GetDocument()->liste.GetSize();i++){
		h2=((ZeichenObject*)GetDocument()->liste[i])->getHighestUndonum();
		if (h2>h){
			h=h2;
			h3=i;
		}
	}
	if (h3>=0){
		((ZeichenObject*)GetDocument()->liste[h3])->undoLastAction(GetDocument()->undonum2);
		this->Invalidate();
	}
	/*CObject* h=this->GetDocument()->DeleteLastObject();
	if (h!=NULL){
		delete h;
		this->GetDocument()->number--;
		this->Invalidate(true);
	}*/
}

void CZeichnenView::OnUpdateButtongerade(CCmdUI* pCmdUI) 
{
	if (objectart==1)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonkreis(CCmdUI* pCmdUI) 
{
	if ((objectart==2)&&(muster==100))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonkreis2(CCmdUI* pCmdUI) 
{
	if ((objectart==2)&&(muster==0))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonlinie(CCmdUI* pCmdUI) 
{
	if (objectart==3)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonrechteck(CCmdUI* pCmdUI) 
{
	if ((objectart==0)&&(muster==100))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonrechteck2(CCmdUI* pCmdUI) 
{
	if ((objectart==0)&&(muster==0))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonred(CCmdUI* pCmdUI) 
{
	if (color==RGB(200,0,0))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonyellow(CCmdUI* pCmdUI) 
{
	if (color==RGB(250,250,0))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtongreen(CCmdUI* pCmdUI) 
{
	if (color==RGB(0,200,0))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonblue(CCmdUI* pCmdUI) 
{
	if (color==RGB(0,0,200))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateButtonblack(CCmdUI* pCmdUI) 
{
	if (color==RGB(0,0,0))
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnButtonfill() 
{
	objectart=4;
}

void CZeichnenView::OnUpdateButtonfill(CCmdUI* pCmdUI) 
{
	if (objectart==4)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnButtonbehind() 
{
	CZeichnenDoc* pDoc = GetDocument();
	int h=pDoc->getlastElementPosition();
	if ((h!=-1)&&(h!=0)){
	 CObject *ho=pDoc->liste[h-1];
	 pDoc->liste[h-1]=pDoc->liste[h];
	 pDoc->liste[h]=ho;
	 this->Invalidate(true);
	}
}

void CZeichnenView::OnButtonfront() 
{
	CZeichnenDoc* pDoc = GetDocument();
	int h=pDoc->getlastElementPosition();
	if ((h!=-1)&&(h!=pDoc->liste.GetSize()-1)){
	 CObject *ho=pDoc->liste[h+1];
	 pDoc->liste[h+1]=pDoc->liste[h];
	 pDoc->liste[h]=ho;
	 this->Invalidate(true);
	}
}

void CZeichnenView::OnUpdateStrichartPunktiert(CCmdUI* pCmdUI) 
{
	if (art==PS_DOT)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichartPunktstrich(CCmdUI* pCmdUI) 
{
	if (art==PS_DASHDOT)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichartStrich(CCmdUI* pCmdUI) 
{
	if (art==PS_SOLID)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichartStrichliert(CCmdUI* pCmdUI) 
{
	if (art==PS_DASH)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichdicke2pt(CCmdUI* pCmdUI) 
{
	if (dicke==2)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichdicke3pt(CCmdUI* pCmdUI) 
{
	if (dicke==3)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichdicke4pt(CCmdUI* pCmdUI) 
{
	if (dicke==4)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichdicke5pt(CCmdUI* pCmdUI) 
{
	if (dicke==5)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichdicke6pt(CCmdUI* pCmdUI) 
{
	if (dicke==6)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CZeichnenView::OnUpdateStrichdicke1pt(CCmdUI* pCmdUI) 
{
	if (dicke==1)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

CString* CZeichnenView::GetStatusText()
{
	CString* name=new CString();
	switch (objectart){
	case 0:{if (muster==0) name->Insert(1,"Rechteck");
			else name->Insert(1,"Rechteck");
			break;}
	case 1:{name->Insert(1,"Gerade");break;}
	case 2:{if (muster==0) name->Insert(1,"leere Ellipse");
			else name->Insert(1,"Ellipse");
			break;}
	case 3:{name->Insert(1,"Freihand");break;}
	case 4:{name->Insert(1,"F�llen");break;}
	case 5:{name->Insert(1,"Zeiger");break;}
	break;
	}
	switch (color){
	case RGB(0,0,0):{name->Insert(name->GetLength(),"   Schwarz");break;}
	case RGB(200,0,0):{name->Insert(name->GetLength(),"   Rot");break;}
	case RGB(0,200,0):{name->Insert(name->GetLength(),"   Gr�n");break;}
	case RGB(0,0,200):{name->Insert(name->GetLength(),"   Blau");break;}
	case RGB(250,250,0):{name->Insert(name->GetLength(),"   Gelb");break;}
	break;
	}
	//if (objecti==NULL)
	//name->Insert(name->GetLength(),"  NULL");
	name->Format("%d %d", x,y);
	return name;
}

void CZeichnenView::OnButtondialog() 
{
	dialogi->DoModal();
	int h[5];
	dialogi->GetWerte(h);
	if (h[0]!=-1) objectart=h[0];
	if (h[1]!=-1) muster=h[1];
	if (h[2]!=-1) art=h[2];
	if (h[3]!=-1) dicke=h[3];
	if (h[4]!=-1) color=h[4];
}

void CZeichnenView::OnButtonzeiger() 
{
	objectart=5;
}

void CZeichnenView::OnUpdateButtonzeiger(CCmdUI* pCmdUI) 
{
	if (objectart==5)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

ZeichenObject* CZeichnenView::GetZeichenObject(int ex, int ey)
{
	ZeichenObject* h=NULL;
	for (int i=GetDocument()->liste.GetSize()-1;i>-1;i--)
		if (((ZeichenObject*)GetDocument()->liste[i])->IsPoint(ex,ey,this->GetDC()->GetPixel(ex,ey))){
			h=(ZeichenObject*)GetDocument()->liste[i];
			break;
		}
	return h;
}
