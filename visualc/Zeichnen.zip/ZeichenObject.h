// ZeichenObject.h: Schnittstelle f�r die Klasse ZeichenObject.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZEICHENOBJECT_H__120AE1B5_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_ZEICHENOBJECT_H__120AE1B5_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



class ZeichenObject : public CObject  
{
public:
	virtual void getPoints(int points[4]);
	virtual void undoLastAction(int undonum2);
	virtual int getHighestUndonum();
	CObArray undoliste;
	virtual void setnum(int newnum);
	virtual int setColor(int newcolor);
	int color;
	virtual boolean IsPoint(int ex, int ey, int ecolor);
	int num;
	DECLARE_SERIAL(ZeichenObject)
	virtual void Serialize(CArchive& ar);
	virtual void setpoint(int x, int y, boolean add);
	virtual void print(CDC *pDC);
	ZeichenObject();
	virtual ~ZeichenObject();

};

#endif // !defined(AFX_ZEICHENOBJECT_H__120AE1B5_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
