#if !defined(AFX_MENUDIALOG_H__74047441_E106_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_MENUDIALOG_H__74047441_E106_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Menudialog.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Menudialog 

class Menudialog : public CDialog
{
// Konstruktion
public:
	void GetWerte(int h[2]);
	Menudialog(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(Menudialog)
	enum { IDD = IDD_DIALOG1 };
	CListBox	m_dickecontrol;
	CListBox	m_farbcontrol;
	CComboBox	m_comcontrol;
	CListBox	m_control;
	CString	m_figur;
	CString	m_strichart;
	CString	m_farbe;
	CString	m_dicke;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(Menudialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(Menudialog)
	afx_msg void OnSelchangeListfigur();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList2();
	afx_msg void OnEditchangeCombo2();
	afx_msg void OnSelchangeList3();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	boolean iscancel;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_MENUDIALOG_H__74047441_E106_11D5_BD76_0040F41E1AF0__INCLUDED_
