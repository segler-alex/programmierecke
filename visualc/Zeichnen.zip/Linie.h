// Linie.h: Schnittstelle f�r die Klasse Linie.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINIE_H__120AE1B9_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
#define AFX_LINIE_H__120AE1B9_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ZeichenObject.h"

class Linie : public ZeichenObject  
{
public:
	boolean IsPoint(int ex, int ey, int ecolor);
	DECLARE_SERIAL(Linie)
	void Serialize(CArchive& ar);
	void setpoint(int x, int y, boolean add);
	Linie(int x, int y, int dicke, int color, int muster);
	void add(int x, int y);
	void print(CDC *pDC);
	Linie();
	virtual ~Linie();

private:
	CObArray punkte;
	int muster;
	int dicke;
};

#endif // !defined(AFX_LINIE_H__120AE1B9_DB4F_11D5_BD76_0040F41E1AF0__INCLUDED_)
