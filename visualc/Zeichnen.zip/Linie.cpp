// Linie.cpp: Implementierung der Klasse Linie.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "Linie.h"
#include "LinienPunkt.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(Linie,ZeichenObject,1)

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

Linie::Linie()
{
}

Linie::~Linie()
{
	for (int i=0;i<punkte.GetSize();i++)
		delete punkte[i];
	punkte.RemoveAll();
	for (int j=0;j<undoliste.GetSize();j++)
		delete undoliste[j];
	undoliste.RemoveAll();
}

void Linie::print(CDC *pDC)
{
 
 CPen *pen=new CPen(muster,dicke,color);
 CPen* oldpen=pDC->SelectObject(pen);
 CPoint* p;
 for (int i=0;i<punkte.GetSize()-1;i++){
	 p=((LinienPunkt*)punkte[i+1])->getpoint();
	 ((LinienPunkt*)punkte[i])->print(pDC,p->x,p->y);
 }
 pDC->SelectObject(oldpen);
 delete pen;
}

void Linie::add(int x, int y)
{
	LinienPunkt* p=new LinienPunkt(x,y);
	punkte.Add(p);
}

Linie::Linie(int x, int y, int dicke, int color, int muster)
{
	this->color=color;
	this->muster=muster;
	this->dicke=dicke;
	add(x,y);
}

void Linie::setpoint(int x, int y, boolean add)
{
	if (!add)
		this->add(x,y);
	else{
	 for (int i=0;i<punkte.GetSize();i++)
		 ((LinienPunkt*)punkte[i])->setpoint(x,y,true);
	}
}

void Linie::Serialize(CArchive &ar)
{
	punkte.Serialize(ar);
	if (ar.IsStoring())
	{
		ar<<color<<muster<<dicke<<num;
	}
	else
	{
		ar>>color>>muster>>dicke>>num;
	}
}

boolean Linie::IsPoint(int ex, int ey, int ecolor)
{
	boolean h=false;
	CPoint* p;
	if (color!=ecolor) return false;
	for (int i=0;i<punkte.GetSize()-1;i++){
		p=((LinienPunkt*)punkte[i+1])->getpoint();
		h=((LinienPunkt*)punkte[i])->IsPoint(ex,ey,p->x,p->y,dicke);
		if (h) break;
	}
	if (h)
		return true;
	return false;
}
