// ZeichnenDoc.cpp : Implementierung der Klasse CZeichnenDoc
//

#include "stdafx.h"
#include "Zeichnen.h"

#include "ZeichnenDoc.h"
#include "ZeichenObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZeichnenDoc

IMPLEMENT_DYNCREATE(CZeichnenDoc, CDocument)

BEGIN_MESSAGE_MAP(CZeichnenDoc, CDocument)
	//{{AFX_MSG_MAP(CZeichnenDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZeichnenDoc Konstruktion/Destruktion

CZeichnenDoc::CZeichnenDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen
	number=0;
	undonum=0;
	undonum2=0;
}

CZeichnenDoc::~CZeichnenDoc()
{
	for (int i=0;i<liste.GetSize();i++)
		delete liste[i];
	liste.RemoveAll();
}

BOOL CZeichnenDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CZeichnenDoc Serialisierung

void CZeichnenDoc::Serialize(CArchive& ar)
{
	liste.Serialize(ar);
	if (ar.IsStoring())
	{
		ar<<number<<undonum<<undonum2;
	}
	else
	{
		ar>>number>>undonum>>undonum2;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CZeichnenDoc Diagnose

#ifdef _DEBUG
void CZeichnenDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CZeichnenDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZeichnenDoc Befehle

int CZeichnenDoc::getlastElementPosition()
{
	int h=-1;
	int hnum=-1;
	for (int i=0;i<liste.GetSize();i++)
		if (((ZeichenObject*)liste[i])->num>hnum){
			hnum=((ZeichenObject*)liste[i])->num;
			h=i;
		}
	return h;
}

CObject* CZeichnenDoc::DeleteLastObject()
{
	CObject* h=NULL;
	if (liste.GetSize()>0){
		int hnum=0,hpos=0;
		for (int i=0;i<liste.GetSize();i++)
			if (hnum<((ZeichenObject*)liste[i])->num){
				hpos=i;
				hnum=((ZeichenObject*)liste[i])->num;
			}
		h=liste.GetAt(hpos);
		liste.RemoveAt(hpos,1);
	}
	return h;
}
