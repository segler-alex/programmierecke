// Kreis.cpp: Implementierung der Klasse Kreis.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "Kreis.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(Kreis,ZeichenObject,1)

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

Kreis::Kreis()
{
}

Kreis::~Kreis()
{
	for (int i=0;i<undoliste.GetSize();i++)
		delete undoliste[i];
	undoliste.RemoveAll();
}

void Kreis::print(CDC *pDC)
{
 CBrush *brush;
 if ((muster==100)||(muster==0))
	brush=new CBrush(color);
 else 
	brush=new CBrush(color,muster);
 CPen *pen=new CPen(PS_SOLID,dicke,color);

 CBrush* oldbrush=pDC->SelectObject(brush);
 if (muster==0)
	pDC->SelectStockObject(NULL_BRUSH);
 CPen* oldpen=pDC->SelectObject(pen);
 
 pDC->Ellipse(x1,y1,x2,y2);

 pDC->SelectObject(oldbrush);
 pDC->SelectObject(oldpen);
 delete pen;
 delete brush;
}

Kreis::Kreis(int x1, int y1, int x2, int y2, int dicke, int color, int muster)
{
	this->x1=x1;
	this->x2=x2;
	this->y1=y1;
	this->y2=y2;
	this->color=color;
	this->muster=muster;
	this->dicke=dicke;
}

void Kreis::setpoint(int x, int y, boolean add)
{
	if (!add){
		this->x2=x;
		this->y2=y;
	}
	else{
	 x1=x1+x;
	 x2=x2+x;
	 y1=y1+y;
	 y2=y2+y;
	}
}

void Kreis::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar<<x1<<y1<<x2<<y2<<color<<muster<<dicke<<num;
	}
	else
	{
		ar>>x1>>y1>>x2>>y2>>color>>muster>>dicke>>num;
	}
}

boolean Kreis::IsPoint(int ex, int ey, int ecolor)
{
	boolean hx=false,hy=false;
	if ((ex>=x1)&&(ex<=x2)) hx=true;
	else
		if ((ex<=x1)&&(ex>=x2)) hx=true;
	if ((ey>=y1)&&(ey<=y2)) hy=true;
	else
		if ((ey<=y1)&&(ey>=y2)) hy=true;
	if (hy&&hx&&color==ecolor) return true;
	return false;
}
