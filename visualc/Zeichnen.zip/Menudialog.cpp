// Menudialog.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Zeichnen.h"
#include "Menudialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld Menudialog 


Menudialog::Menudialog(CWnd* pParent /*=NULL*/)
	: CDialog(Menudialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(Menudialog)
	m_figur = _T("");
	m_strichart = _T("");
	m_farbe = _T("");
	m_dicke = _T("");
	//}}AFX_DATA_INIT
}


void Menudialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Menudialog)
	DDX_Control(pDX, IDC_LIST3, m_dickecontrol);
	DDX_Control(pDX, IDC_LIST2, m_farbcontrol);
	DDX_Control(pDX, IDC_COMBO2, m_comcontrol);
	DDX_Control(pDX, IDC_LIST1, m_control);
	DDX_LBString(pDX, IDC_LIST1, m_figur);
	DDX_CBString(pDX, IDC_COMBO2, m_strichart);
	DDX_LBString(pDX, IDC_LIST2, m_farbe);
	DDX_LBString(pDX, IDC_LIST3, m_dicke);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Menudialog, CDialog)
	//{{AFX_MSG_MAP(Menudialog)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeListfigur)
	ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
	ON_CBN_EDITCHANGE(IDC_COMBO2, OnEditchangeCombo2)
	ON_LBN_SELCHANGE(IDC_LIST3, OnSelchangeList3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten Menudialog 

void Menudialog::OnSelchangeListfigur() 
{
	this->UpdateData(true);
}

BOOL Menudialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	iscancel=false;
	m_control.AddString("volles Rechteck");
	m_control.AddString("leeres Rechteck");
	m_control.AddString("volle Ellipse");
	m_control.AddString("leere Ellipse");
	m_control.AddString("Gerade");
	m_control.AddString("Freihand");
	m_control.AddString("F�llen");
	m_comcontrol.AddString("Strich");
	m_comcontrol.AddString("Punktiert");
	m_comcontrol.AddString("Strichliert");
	m_comcontrol.AddString("Punktstrich");
	m_dickecontrol.AddString("1");
	m_dickecontrol.AddString("2");
	m_dickecontrol.AddString("3");
	m_dickecontrol.AddString("4");
	m_dickecontrol.AddString("5");
	m_dickecontrol.AddString("6");
	m_farbcontrol.AddString("Schwarz");
	m_farbcontrol.AddString("Blau");
	m_farbcontrol.AddString("Gr�n");
	m_farbcontrol.AddString("Gelb");
	m_farbcontrol.AddString("Rot");

	m_comcontrol.SetCurSel(0);
	// TODO: Zus�tzliche Initialisierung hier einf�gen
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void Menudialog::GetWerte(int h[5])
{
	h[0]=-1;
	h[1]=-1;
	h[2]=-1;
	h[3]=-1;
	h[4]=-1;
	if (iscancel==false){
		if (m_figur=="volles Rechteck"){h[0]=0;h[1]=100;}
		if (m_figur=="leeres Rechteck"){h[0]=0;h[1]=0;}
		if (m_figur=="volle Ellipse"){h[0]=2;h[1]=100;}
		if (m_figur=="leere Ellipse"){h[0]=2;h[1]=0;}
		if (m_figur=="Gerade") h[0]=1;
		if (m_figur=="Freihand") h[0]=3;
		if (m_figur=="F�llen") h[0]=4;
		if (m_strichart=="Strich") h[2]=PS_SOLID;
		if (m_strichart=="Punktiert") h[2]=PS_DOT;
		if (m_strichart=="Strichliert") h[2]=PS_DASH;
		if (m_strichart=="Punktstrich") h[2]=PS_DASHDOT;
		if (m_dicke=="1") h[3]=1;
		if (m_dicke=="2") h[3]=2;
		if (m_dicke=="3") h[3]=3;
		if (m_dicke=="4") h[3]=4;
		if (m_dicke=="5") h[3]=5;
		if (m_dicke=="6") h[3]=6;
		if (m_farbe=="Schwarz") h[4]=RGB(0,0,0);
		if (m_farbe=="Blau") h[4]=RGB(0,0,200);
		if (m_farbe=="Gr�n") h[4]=RGB(0,200,0);
		if (m_farbe=="Gelb") h[4]=RGB(250,250,0);
		if (m_farbe=="Rot") h[4]=RGB(200,0,0);
	}
	//CString* s=new CString();
	//s->Format("%d %d",h[0], h[1]);
	//AfxMessageBox(m_figur+" "+s->GetBuffer(1));
}

void Menudialog::OnSelchangeList2() 
{
	this->UpdateData(true);
}

void Menudialog::OnEditchangeCombo2() 
{
	this->UpdateData(true);
}

void Menudialog::OnSelchangeList3() 
{
	this->UpdateData(true);
}

void Menudialog::OnCancel() 
{
	iscancel=true;
	CDialog::OnCancel();
}
