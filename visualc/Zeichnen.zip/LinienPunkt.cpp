// LinienPunkt.cpp: Implementierung der Klasse LinienPunkt.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "LinienPunkt.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IMPLEMENT_SERIAL(LinienPunkt,CObject,1)

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

LinienPunkt::LinienPunkt()
{

}

LinienPunkt::~LinienPunkt()
{

}

void LinienPunkt::print(CDC *pDC, int ex, int ey)
{
	pDC->MoveTo(x,y);
	pDC->LineTo(ex,ey);
}

LinienPunkt::LinienPunkt(int x, int y)
{
	this->x=x;
	this->y=y;
}

CPoint* LinienPunkt::getpoint()
{
	CPoint* p=new CPoint(x,y);
	return p;
}

void LinienPunkt::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar<<x<<y;
	}
	else
	{
		ar>>x>>y;
	}
}

boolean LinienPunkt::IsPoint(int ex, int ey, int ex2, int ey2, int dicke)
{
	boolean hx,hy;
	int h;
	for(int i=-(dicke/2);i<=(dicke/2);i++){
		hx=false;hy=false;
		h=((ex2-x)*(ey+i-y))-((ex-x)*(ey2-y));
		if ((h>=-0.2*(ey+i-y)*(ey2-y))&&(h<=0.2*(ey+i-y)*(ey2-y))){
			if ((ex>=x)&&(ex<=ex2)) hx=true;
			else
				if ((ex<=x)&&(ex>=ex2)) hx=true;
			if ((ey>=y)&&(ey<=ey2)) hy=true;
			else
				if ((ey<=y)&&(ey>=ey2)) hy=true;
		}
		if (hy&&hx)
			return true;
		hx=false;hy=false;
		h=((ex2-x)*(ey-y))-((ex+i-x)*(ey2-y));
		if ((h>=-0.2*(ey-y)*(ey2-y))&&(h<=0.2*(ey-y)*(ey2-y))){
			if ((ex>=x)&&(ex<=ex2)) hx=true;
			else
				if ((ex<=x)&&(ex>=ex2)) hx=true;
			if ((ey>=y)&&(ey<=ey2)) hy=true;
			else
				if ((ey<=y)&&(ey>=ey2)) hy=true;
		}
		if (hy&&hx)
			return true;
	}
	return false;
}

void LinienPunkt::setpoint(int ex, int ey, boolean add)
{
	if (!add){
		x=ex;
		y=ey;
	}
	else{
		x=x+ex;
		y=y+ey;
	}
}
